@echo off
rem ===================================================================
rem  LoL / TFT Auto Accept v2.2 - diagnostics (console build)
rem  Pure ASCII + CRLF on purpose (see run.bat).
rem ===================================================================
setlocal
set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"
cd /d "%~dp0"

echo  Running the app in this console so errors stay visible.
echo  Closing this window closes the app too.
echo.

set "PYCMD="
where python.exe >nul 2>nul
if not errorlevel 1 (
    python -c "import sys;assert sys.version_info[0]>=3" >nul 2>nul
    if not errorlevel 1 set "PYCMD=python"
)
if not defined PYCMD (
    where py.exe >nul 2>nul
    if not errorlevel 1 (
        py -3 -c "import sys;assert sys.version_info[0]>=3" >nul 2>nul
        if not errorlevel 1 set "PYCMD=py -3"
    )
)
if not defined PYCMD goto nopython

%PYCMD% -c "import tkinter" 2>nul
if errorlevel 1 (
    echo  [check] Python found but tkinter ^(GUI toolkit^) is missing.
    echo          Reinstall Python with "tcl/tk and IDLE" checked.
    echo.
)

%PYCMD% "%~dp0app.pyw"
echo.
echo  The app has closed. If a red error message appears above, copy it.
pause
exit /b 0

:nopython
echo  [error] Python 3 not found.
echo          Install from https://www.python.org/downloads/
echo          and tick "Add python.exe to PATH".
pause
exit /b 1
