#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
롤 / 롤토체스(TFT) 매칭 자동 수락 엔진
=========================================

리그 오브 레전드 클라이언트(LCU)의 로컬 API 만 사용합니다.
계정 로그인, 토큰 탈취, 이미지 인식, 메모리 조작은 하지 않습니다.

v2 에서 달라진 점 (v1 이 롤토체스에서 수락하지 못한 이유)
--------------------------------------------------------
v1 은 `/lol-gameflow/v1/gameflow-phase` 문자열이 정확히 "ReadyCheck" 인
순간에만 동작했고, 1초 지연 뒤에 **다시 phase 가 ReadyCheck 인지 확인해서**
다르면 수락을 포기했습니다. 그런데 롤토체스는 큐가 lol-lobby(파티) 쪽
매치메이킹으로 흘러가서, 매치가 잡힌 사실이 ready-check 리소스에는 먼저
올라오지만 gameflow phase 는 늦게(또는 아주 짧게) "ReadyCheck" 로 바뀝니다.
그래서 v1 은 (a) 아예 트리거되지 않거나 (b) 1초 뒤 재확인 단계에서 취소되어
롤토체스 매치를 놓쳤습니다.

v2 는 두 신호를 동시에 봅니다.
  * `GET /lol-matchmaking/v1/ready-check` → state == "InProgress"
    이고 playerResponse == "None" 이면 수락 대상 (모든 큐 공통)
  * `GET /lol-gameflow/v1/gameflow-phase` == "ReadyCheck" 이면 보조 신호
어느 한쪽만 잡혀도 수락합니다. queueId 필터는 두지 않습니다(모든 큐 대응).

수락 요청은 `POST /lol-matchmaking/v1/ready-check/accept` 하나입니다.

v2.2 에서 달라진 점 (몇 초 후 수락)
---------------------------------
* 수락 지연을 고정 2버튼(1.0초 / 즉시)에서 **즉시·1·2·3·4·5초** 중에서 고를 수 있게
  바꿨습니다. 고른 값은 settings.json 에 그대로 저장됩니다.
* `normalize_delay()` 가 잘못된 값(None·문자열·NaN·범위 밖)을 0.0~5.0초 안으로
  안전하게 보정합니다. 기존 settings.json(accept_delay 0.0 / 1.0)은 그대로 읽힙니다.
"""

import base64
import http.client
import json
import math
import os
import queue
import re
import ssl
import subprocess
import threading
import time

# ---------------------------------------------------------------------------
# 설정값
# ---------------------------------------------------------------------------
POLL_INTERVAL = 0.2           # 매칭 감시 주기 (초)
IDLE_POLL_INTERVAL = 1.0      # 자동 수락이 꺼져 있을 때 연결 확인 주기 (초)
ACCEPT_DELAY = 1.0            # 매칭이 잡힌 뒤 수락까지 기다리는 시간 (기본값, 초)
DELAY_MIN = 0.0               # 고를 수 있는 가장 짧은 지연 (즉시)
DELAY_MAX = 5.0               # 고를 수 있는 가장 긴 지연 (초)
DELAY_OPTIONS = (0.0, 1.0, 2.0, 3.0, 4.0, 5.0)   # 화면의 빠른 선택 버튼
RECONNECT_INTERVAL = 2.0      # 클라이언트 재연결 시도 주기 (초)
PROC_CHECK_INTERVAL = 10.0    # 프로세스 목록 조회 최소 간격 (초)
HTTP_TIMEOUT = 2.5            # LCU 요청 타임아웃 (초)
PROC_TIMEOUT = 10.0           # PowerShell / wmic 명령 타임아웃 (초)
CREATE_NO_WINDOW = 0x08000000 # 하위 프로세스 콘솔 창 숨김

GAMEFLOW_PHASE_PATH = "/lol-gameflow/v1/gameflow-phase"
GAMEFLOW_SESSION_PATH = "/lol-gameflow/v1/session"
READY_CHECK_PATH = "/lol-matchmaking/v1/ready-check"
READY_CHECK_ACCEPT_PATH = "/lol-matchmaking/v1/ready-check/accept"

LOCKFILE_ENV = "LOL_AUTO_ACCEPT_LOCKFILE"

# 화면 상태 (level 은 UI 색상 선택에 쓴다)
LEVEL_IDLE = "idle"      # 회색 : 클라이언트 없음 / 꺼짐
LEVEL_OK = "ok"          # 파랑 : 대기·탐색
LEVEL_FOUND = "found"    # 골드 : 매칭 잡힘
LEVEL_DONE = "done"      # 초록 : 수락 완료
LEVEL_WARN = "warn"      # 빨강 : 취소·거절

# queueId → 화면에 보여줄 모드 이름
QUEUE_NAMES = {
    400: "일반 (드래프트)",
    420: "솔로 랭크",
    430: "일반 (블라인드)",
    440: "자유 랭크",
    450: "칼바람 나락",
    490: "빠른 대전",
    700: "격전",
    720: "칼바람 나락 (격전)",
    900: "우르프",
    1020: "원 포 올",
    1300: "넥서스 파괴",
    1400: "궁극기 주문서",
    1700: "아레나",
    1710: "아레나",
    1750: "아레나",
    1900: "우르프 (2024)",
    # 롤토체스(TFT)
    1090: "롤토체스 (일반)",
    1100: "롤토체스 (랭크)",
    1110: "롤토체스 (튜토리얼)",
    1130: "롤토체스 (하이퍼 롤)",
    1150: "롤토체스 (일반)",
    1160: "롤토체스 (더블 업)",
    1210: "롤토체스 (일반)",
    1220: "롤토체스 (발명가의 시련)",
}

TFT_QUEUE_IDS = (1090, 1100, 1110, 1130, 1150, 1160, 1210, 1220)


def normalize_delay(value, default=ACCEPT_DELAY):
    """수락 지연 값을 0.0~5.0초(소수점 1자리)로 안전하게 보정한다.

    * 숫자로 읽을 수 없으면 default (기본 1.0초)
    * NaN / 무한대 → default
    * 범위 밖 → 가장 가까운 경계 (음수 → 0.0, 5.0 초과 → 5.0)
    """
    try:
        seconds = float(value)
    except (TypeError, ValueError):
        return float(default)
    if math.isnan(seconds) or math.isinf(seconds):
        return float(default)
    if seconds <= DELAY_MIN:
        return DELAY_MIN
    if seconds >= DELAY_MAX:
        return DELAY_MAX
    return round(seconds, 1)


def delay_text(seconds):
    """'3.0' → '3초', '1.5' → '1.5초', '0' → '즉시' (화면·로그용)."""
    seconds = normalize_delay(seconds)
    if seconds <= 0:
        return "즉시"
    if abs(seconds - round(seconds)) < 1e-9:
        return "{}초".format(int(round(seconds)))
    return "{:.1f}초".format(seconds)


def remaining_text(seconds):
    """남은 지연 표사: 2.96 → '3초', 0.84 → '0.8초', 0.01 → '0.1초'."""
    try:
        seconds = float(seconds)
    except (TypeError, ValueError):
        return "0.1초"
    if math.isnan(seconds) or math.isinf(seconds) or seconds <= 0.05:
        return "0.1초"
    return delay_text(min(seconds, DELAY_MAX))


def queue_label(queue_id):
    """queueId → 화면용 모드 이름. 모르는 큐는 '기타 모드'."""
    try:
        return QUEUE_NAMES.get(int(queue_id), "기타 모드")
    except (TypeError, ValueError):
        return "기타 모드"


def is_tft_queue(queue_id):
    try:
        return int(queue_id) in TFT_QUEUE_IDS
    except (TypeError, ValueError):
        return False


# ---------------------------------------------------------------------------
# 예외
# ---------------------------------------------------------------------------
class LcuError(Exception):
    """LCU 가 응답했지만 결과가 정상이 아닐 때."""

    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


class SessionExpired(LcuError):
    """인증 정보(포트/비밀번호)가 더 이상 유효하지 않을 때."""


class NotConnected(LcuError):
    """클라이언트에 아예 연결할 수 없을 때."""


class NotFound(LcuError):
    """해당 리소스가 지금은 없을 때. (예: 매칭 중이 아님 → 404)"""


# ---------------------------------------------------------------------------
# lockfile 탐색
# ---------------------------------------------------------------------------
def parse_lockfile(path):
    """lockfile 형식: name:pid:port:password:protocol"""
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as fp:
            content = fp.read().strip()
    except OSError:
        return None

    parts = content.split(":")
    if len(parts) < 5:
        return None

    name, pid, port, password, protocol = parts[0], parts[1], parts[2], parts[3], parts[4]
    try:
        port_number = int(port)
    except (TypeError, ValueError):
        return None
    if not password or not (0 < port_number < 65536):
        return None

    return {
        "port": port_number,
        "password": password,
        "protocol": protocol or "https",
        "pid": pid,
        "name": name,
        "path": path,
    }


def parse_lockfile_text(text, source="lockfile"):
    """lockfile 내용 문자열을 직접 파싱한다. (테스트/직접 지정용)"""
    parts = (text or "").strip().split(":")
    if len(parts) < 5:
        return None
    try:
        port_number = int(parts[2])
    except (TypeError, ValueError):
        return None
    if not parts[3] or not (0 < port_number < 65536):
        return None
    return {
        "port": port_number,
        "password": parts[3],
        "protocol": parts[4] or "https",
        "pid": parts[1],
        "name": parts[0],
        "path": source,
    }


def registry_install_dirs():
    """레지스트리에 기록된 롤 설치 경로. Windows 가 아니거나 실패하면 빈 목록."""
    if os.name != "nt":
        return []
    found = []
    try:
        import winreg
    except ImportError:
        return []

    keys = [
        (winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Uninstall\Riot Game league_of_legends.live"),
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\Riot Game league_of_legends.live"),
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\Riot Game league_of_legends.live"),
    ]
    for root, subkey in keys:
        try:
            with winreg.OpenKey(root, subkey) as key:
                for value_name in ("InstallLocation", "DisplayIcon", "UninstallString"):
                    try:
                        value, _ = winreg.QueryValueEx(key, value_name)
                    except OSError:
                        continue
                    if not isinstance(value, str) or not value:
                        continue
                    value = value.strip('"')
                    if value.lower().endswith(".exe"):
                        value = os.path.dirname(value)
                    if value and value not in found:
                        found.append(value)
        except OSError:
            continue
    return found


def lockfile_candidates(extra_path=None):
    """lockfile 이 있을 만한 경로들을 우선순위대로 돌려준다."""
    candidates = []
    seen = set()

    def add(path):
        if not path:
            return
        key = os.path.normcase(os.path.normpath(path))
        if key in seen:
            return
        seen.add(key)
        candidates.append(path)

    # 0) 직접 지정한 경로 / 환경 변수
    if extra_path:
        add(extra_path)
    env_path = os.environ.get(LOCKFILE_ENV)
    if env_path:
        add(env_path)

    # 1) 주요 드라이브의 기본 설치 경로
    drives = []
    if os.name == "nt":
        for letter in "CDEFGHIJKLMNOPQRSTUVWXYZ":
            if os.path.exists(letter + ":\\"):
                drives.append(letter + ":")
    else:
        drives = ["C:", "D:", "E:"]

    relative_paths = (
        r"\Riot Games\League of Legends\lockfile",
        r"\Program Files\Riot Games\League of Legends\lockfile",
        r"\Program Files (x86)\Riot Games\League of Legends\lockfile",
        r"\Games\Riot Games\League of Legends\lockfile",
        r"\Riot Games\League of Legends\Game\lockfile",
    )
    for drive in drives:
        for relative in relative_paths:
            add(drive + relative)

    # 2) 레지스트리 설치 경로
    for install_dir in registry_install_dirs():
        add(os.path.join(install_dir, "lockfile"))

    return candidates


def find_lockfile(extra_path=None):
    for path in lockfile_candidates(extra_path):
        info = parse_lockfile(path)
        if info:
            return info
    return None


# ---------------------------------------------------------------------------
# 프로세스 실행 인자에서 접속 정보 찾기 (lockfile 이 없을 때)
# ---------------------------------------------------------------------------
def run_hidden(command, timeout=PROC_TIMEOUT):
    kwargs = {"stdout": subprocess.PIPE, "stderr": subprocess.PIPE, "timeout": timeout}
    if os.name == "nt":
        kwargs["creationflags"] = CREATE_NO_WINDOW
    try:
        completed = subprocess.run(command, **kwargs)
    except (OSError, subprocess.SubprocessError):
        return ""

    chunks = []
    for raw in (completed.stdout, completed.stderr):
        if not raw:
            continue
        chunks.append(raw.decode("utf-8", "replace") if isinstance(raw, bytes) else raw)
    return "\n".join(chunks)


def extract_from_command_line(text):
    """LeagueClientUx.exe 실행 인자에서 app-port / remoting-auth-token 을 뽑는다."""
    if not text:
        return None
    port_match = re.search(r"--app-port=(\d+)", text)
    token_match = re.search(r"--remoting-auth-token=([\w\-]+)", text)
    if not port_match or not token_match:
        return None
    try:
        port_number = int(port_match.group(1))
    except ValueError:
        return None
    if not (0 < port_number < 65536):
        return None
    return {
        "port": port_number,
        "password": token_match.group(1),
        "protocol": "https",
        "path": "LeagueClientUx.exe 프로세스 인자",
    }


def find_lockfile_from_process():
    """PowerShell 우선, 실패하면 wmic 로 클라이언트 프로세스 인자를 읽는다."""
    if os.name != "nt":
        return None

    ps_command = (
        "Get-CimInstance Win32_Process -Filter \"Name='LeagueClientUx.exe'\" "
        "| Select-Object -ExpandProperty CommandLine"
    )
    info = extract_from_command_line(run_hidden([
        "powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps_command,
    ]))
    if info:
        return info

    info = extract_from_command_line(run_hidden([
        "wmic", "PROCESS", "WHERE", "name='LeagueClientUx.exe'", "GET", "CommandLine", "/FORMAT:LIST",
    ]))
    return info


# ---------------------------------------------------------------------------
# LCU 연결
# ---------------------------------------------------------------------------
class LcuConnection:
    """롤 클라이언트 로컬 API 와 통신하는 최소 클라이언트 (표준 라이브러리만 사용)."""

    def __init__(self, lockfile_override=None, timeout=HTTP_TIMEOUT, discover=None):
        self.lockfile_override = lockfile_override
        self.timeout = timeout
        self.port = None
        self.password = None
        self.source = None
        self._discover = discover
        self._last_proc_check = None
        self._conn = None
        self.ssl_context = self._make_ssl_context()

    # -- 접속 정보 ---------------------------------------------------------
    @staticmethod
    def _make_ssl_context():
        # LCU 는 자체 서명 인증서를 쓴다. (로컬 127.0.0.1 전용)
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        return ctx

    def reset(self):
        self.port = None
        self.password = None
        self.source = None
        self._close()

    def _close(self):
        if self._conn is not None:
            try:
                self._conn.close()
            except Exception:
                pass
            self._conn = None

    def discover(self):
        """lockfile → 프로세스 인자 순으로 접속 정보를 찾는다. 찾으면 True."""
        if self._discover is not None:
            info = self._discover()
        else:
            info = find_lockfile(self.lockfile_override)
        if not info:
            now = time.monotonic()
            if self._last_proc_check is not None and (now - self._last_proc_check) < PROC_CHECK_INTERVAL:
                return False
            self._last_proc_check = now
            info = find_lockfile_from_process() if self._discover is None else None
        if not info:
            return False
        self.port = info["port"]
        self.password = info["password"]
        self.source = info["path"]
        self._close()
        return True

    # 테스트에서 접속 정보를 직접 넣을 때
    def use(self, port, password, source="직접 지정"):
        self.port = port
        self.password = password
        self.source = source
        self._close()

    # -- HTTP -------------------------------------------------------------
    def _auth_header(self):
        token = base64.b64encode(("riot:" + str(self.password)).encode("utf-8")).decode("ascii")
        return "Basic " + token

    @property
    def connected(self):
        return bool(self.port and self.password)

    def request(self, method, path, body=None):
        """요청 후 (status, body bytes) 반환. 실패는 예외로 구분한다."""
        if not self.connected:
            raise NotConnected("접속 정보가 없습니다.")

        payload = b""
        if body is not None:
            payload = json.dumps(body).encode("utf-8") if not isinstance(body, (bytes, bytearray)) else bytes(body)

        try:
            return self._send(method, path, payload)
        except (NotConnected, SessionExpired, NotFound, LcuError):
            raise
        except Exception:
            # keep-alive 연결이 끊긴 경우 한 번만 새 연결로 재시도
            self._close()
            return self._send(method, path, payload)

    def _send(self, method, path, payload):
        if self._conn is None:
            self._conn = http.client.HTTPSConnection(
                "127.0.0.1", self.port, timeout=self.timeout, context=self.ssl_context
            )
        headers = {"Authorization": self._auth_header(), "Accept": "application/json"}
        if method in ("POST", "PUT", "PATCH"):
            headers["Content-Type"] = "application/json"
        try:
            self._conn.request(method, path, body=payload, headers=headers)
            response = self._conn.getresponse()
            data = response.read()
            status = response.status
            if response.will_close:
                self._close()
        except ssl.SSLError as exc:
            self._close()
            raise NotConnected("보안 연결에 실패했습니다. ({})".format(exc))
        except (ConnectionError, http.client.HTTPException, OSError) as exc:
            self._close()
            raise NotConnected("롤 클라이언트에 연결할 수 없습니다. ({})".format(exc))

        if status in (401, 403):
            raise SessionExpired("인증 정보가 만료되었습니다. (HTTP {})".format(status), status=status)
        if status == 404:
            raise NotFound("요청한 정보가 없습니다. ({})".format(path), status=404)
        if not (200 <= status < 300):
            raise LcuError("HTTP {} {}".format(status, path), status=status)
        return status, data

    # -- 편의 함수 ---------------------------------------------------------
    def get_json(self, path):
        _, body = self.request("GET", path)
        if not body:
            return None
        try:
            return json.loads(body.decode("utf-8", "replace"))
        except ValueError:
            raise LcuError("응답을 해석할 수 없습니다. ({})".format(path))

    def get_text(self, path):
        _, body = self.request("GET", path)
        try:
            return json.loads(body.decode("utf-8", "replace"))
        except ValueError:
            return body.decode("utf-8", "replace")

    def get_phase(self):
        phase = self.get_json(GAMEFLOW_PHASE_PATH)
        if not isinstance(phase, str):
            raise LcuError("게임 상태 응답 형식이 예상과 다릅니다.")
        return phase

    def get_ready_check(self):
        """ready-check 리소스. 없으면 None(404). dict 또는 None."""
        try:
            data = self.get_json(READY_CHECK_PATH)
        except NotFound:
            return None
        return data if isinstance(data, dict) else None

    def get_queue_id(self):
        """현재 큐 id (모르면 None). lobby → session 순으로 시도."""
        for path, pick in (
            ("/lol-lobby/v2/lobby", lambda d: (d.get("gameConfig") or {}).get("queueId")),
            (GAMEFLOW_SESSION_PATH, lambda d: ((d.get("gameData") or {}).get("queue") or {}).get("id")),
        ):
            try:
                data = self.get_json(path)
            except (NotFound, LcuError, NotConnected, SessionExpired):
                continue
            if isinstance(data, dict):
                value = pick(data)
                if value:
                    return value
        return None

    def accept_ready_check(self):
        """POST /lol-matchmaking/v1/ready-check/accept"""
        try:
            status, _ = self.request("POST", READY_CHECK_ACCEPT_PATH, body={})
        except NotFound:
            return False
        except LcuError as exc:
            if exc.status == 409:      # 이미 응답했거나 매칭이 사라짐
                return False
            raise
        return 200 <= status < 300


# ---------------------------------------------------------------------------
# 엔진
# ---------------------------------------------------------------------------
class Status:
    """화면에 그대로 쓸 수 있는 상태 한 벌."""

    __slots__ = ("title", "detail", "level", "queue")

    def __init__(self, title, detail="", level=LEVEL_IDLE, queue=None):
        self.title = title
        self.detail = detail
        self.level = level
        self.queue = queue

    def as_dict(self):
        return {"title": self.title, "detail": self.detail, "level": self.level, "queue": self.queue}

    def __eq__(self, other):
        return isinstance(other, Status) and self.as_dict() == other.as_dict()

    def __repr__(self):
        return "Status({!r}, {!r}, {!r}, {!r})".format(self.title, self.detail, self.level, self.queue)


class AutoAcceptEngine:
    """매칭을 감시하고 수락하는 상태 머신.

    tick() 한 번이 "0.2초짜리 한 순간"이다. 네트워크·시계를 밖에서 넣을 수 있어
    단위 테스트에서 시간을 마음대로 흘려보낼 수 있다.
    """

    def __init__(self, connection=None, accept_delay=ACCEPT_DELAY, on_event=None,
                 clock=time.monotonic):
        self.conn = connection if connection is not None else LcuConnection()
        self.accept_delay = normalize_delay(accept_delay)
        self.enabled = False
        self.accept_count = 0
        self.status = Status("자동 수락 꺼짐", "스위치를 켜면 매칭을 감시합니다.", LEVEL_IDLE)
        self.queue_id = None
        self._on_event = on_event
        self._clock = clock
        self._stop = threading.Event()
        self._wake = threading.Event()
        self._commands = queue.Queue()

        # 매칭 1건(세션) 단위 상태
        self._in_session = False
        self._deadline = None
        self._answered = False
        self._last_phase = None
        self._last_conn_error = None
        self._queue_looked_up = False

    # -- 바깥에서 쓰는 설정 -------------------------------------------------
    def set_enabled(self, enabled):
        enabled = bool(enabled)
        if enabled == self.enabled:
            return
        self.enabled = enabled
        if enabled:
            self._emit_log("자동 수락을 켰습니다. ({} 지연)".format(self.delay_label()))
            self._reset_session()
            self._set_status(self._status_for_phase(self._last_phase))
        else:
            self._reset_session()
            self._set_status(Status("자동 수락 꺼짐", "매칭을 지켜보지 않습니다.", LEVEL_IDLE))
            self._emit_log("자동 수락을 껐습니다.")

    def set_delay(self, seconds):
        self.accept_delay = normalize_delay(seconds)
        self._emit_log("수락 지연: {}".format(self.delay_label()))

    def delay_label(self):
        if self.accept_delay <= 0:
            return "즉시 수락"
        return "{} 지연".format(delay_text(self.accept_delay))

    def stop(self):
        self._stop.set()
        self._wake.set()

    # -- UI 스레드 → 감시 스레드 명령 ---------------------------------------
    def submit(self, name, value=None):
        """스위치/지연 변경을 감시 스레드에 맡긴다. (스레드 경합 방지)"""
        self._commands.put((name, value))
        self._wake.set()

    def apply_commands(self):
        while True:
            try:
                name, value = self._commands.get_nowait()
            except queue.Empty:
                return
            if name == "enabled":
                self.set_enabled(value)
            elif name == "delay":
                self.set_delay(value)

    # -- 이벤트 -------------------------------------------------------------
    def _emit_log(self, message):
        if self._on_event:
            self._on_event("log", message)

    def _set_status(self, status):
        if status != self.status:
            self.status = status
            if self._on_event:
                self._on_event("status", status.as_dict())

    def _emit(self, kind, payload):
        if self._on_event:
            self._on_event(kind, payload)

    # -- 세션 ---------------------------------------------------------------
    def _reset_session(self):
        self._in_session = False
        self._deadline = None
        self._answered = False

    # -- 상태 문구 ----------------------------------------------------------
    def _status_for_phase(self, phase, queue=None):
        if not self.enabled:
            return Status("자동 수락 꺼짐", "스위치를 켜면 매칭을 감시합니다.", LEVEL_IDLE)
        if phase is None:
            return Status("클라이언트 연결됨", "로비에서 매칭을 시작하세요.", LEVEL_OK, queue)
        if phase == "Lobby" or phase == "None":
            return Status("클라이언트 연결됨", "로비에서 매칭을 시작하세요.", LEVEL_OK, queue)
        if phase == "Matchmaking":
            return Status("매칭 탐색 중", "매칭이 잡히면 자동으로 수락합니다.", LEVEL_OK, queue)
        if phase == "ChampSelect":
            return Status("챔피언 선택 중", "게임 준비 화면입니다.", LEVEL_OK, queue)
        if phase in ("GameStart", "InProgress", "Reconnect"):
            return Status("게임 진행 중", "게임이 끝나면 다시 감시합니다.", LEVEL_OK, queue)
        if phase in ("WaitingForStats", "PreEndOfGame", "EndOfGame", "Terminated"):
            return Status("게임 종료", "결과 화면입니다.", LEVEL_OK, queue)
        return Status("대기 중", phase, LEVEL_OK, queue)

    # -- 한 번의 감시 -------------------------------------------------------
    def tick(self):
        """한 번 감시하고 현재 상태를 돌려준다. 예외를 밖으로 던지지 않는다."""
        if not self.conn.connected and not self.conn.discover():
            self._reset_session()
            self._last_phase = None
            self._set_status(Status("클라이언트 대기 중", "롤 클라이언트를 실행하면 자동으로 연결됩니다.", LEVEL_IDLE))
            return self.status

        try:
            self._tick_connected()
        except SessionExpired:
            # 클라이언트 재시작 등으로 포트/토큰이 바뀐 경우
            self.conn.reset()
            self._reset_session()
            self._set_status(Status("클라이언트 대기 중", "클라이언트에 다시 연결하는 중입니다.", LEVEL_IDLE))
        except NotConnected:
            self.conn.reset()
            self._reset_session()
            self._last_phase = None
            self._set_status(Status("클라이언트 대기 중", "롤 클라이언트를 실행하면 자동으로 연결됩니다.", LEVEL_IDLE))
        except LcuError:
            # gameflow 준비 전(404 등) : 잠시 뒤 다시 본다
            pass
        return self.status

    def _tick_connected(self):
        phase = None
        phase_error = False
        try:
            phase = self.conn.get_phase()
        except NotFound:
            phase = None
        except (SessionExpired, NotConnected):
            raise
        except LcuError:
            phase_error = True

        if phase is not None and phase != self._last_phase:
            self._last_phase = phase
            self._queue_looked_up = False

        # 큐(모드) 이름은 상태가 바뀔 때만 확인한다 (요청 최소화)
        if self.enabled and not self._queue_looked_up:
            self._queue_looked_up = True
            try:
                self.queue_id = self.conn.get_queue_id()
            except (LcuError, SessionExpired, NotConnected):
                self.queue_id = None
        queue = queue_label(self.queue_id) if self.queue_id else None

        if not self.enabled:
            self._reset_session()
            self._set_status(Status("자동 수락 꺼짐", "스위치를 켜면 매칭을 감시합니다.",
                                    LEVEL_IDLE, queue))
            return

        # 1) ready-check 리소스 (모든 큐 공통 신호)
        ready = None
        try:
            ready = self.conn.get_ready_check()
        except NotFound:
            ready = None
        except (SessionExpired, NotConnected):
            raise
        except LcuError:
            ready = None

        state = (ready or {}).get("state")
        response = (ready or {}).get("playerResponse") or "None"
        rc_active = (state == "InProgress")
        needs_answer = rc_active and response == "None"
        already_answered = rc_active and response in ("Accepted", "Declined", "Exception")

        # 2) gameflow phase (보조 신호) - ready-check 가 안 잡혀도 놓치지 않는다
        phase_ready = (phase == "ReadyCheck")
        active = needs_answer or (phase_ready and not rc_active)

        # 매칭이 이미 처리된 상태
        if already_answered:
            if not self._answered:
                self._answered = True
                self._in_session = False
                if response == "Accepted":
                    self._emit_log("이미 수락된 매칭입니다.")
                    self._set_status(Status("수락 완료!", "다음 매칭을 기다립니다.", LEVEL_DONE, queue))
                else:
                    self._emit_log("매칭이 취소되었습니다. ({})".format(response))
                    self._set_status(Status("매칭 취소됨", "다른 사람이 수락하지 않았습니다.", LEVEL_WARN, queue))
            return

        if not active:
            if self._in_session and not self._answered:
                # 지연 대기 중에 매칭이 사라졌다
                self._emit_log("매칭이 사라져 수락을 건너뜁니다.")
            self._reset_session()
            self._set_status(self._status_for_phase(phase, queue))
            return

        # 3) 매칭 발견
        now = self._clock()
        if not self._in_session:
            self._in_session = True
            self._answered = False
            self._deadline = now + self.accept_delay
            self._emit("found", {"queue": queue, "delay": self.accept_delay})
            if self.accept_delay > 0:
                self._emit_log("매칭 잡힘! {} 뒤 수락합니다.".format(delay_text(self.accept_delay)))
            else:
                self._emit_log("매칭 잡힘! 바로 수락합니다.")
            detail = ("{} 후 자동 수락".format(delay_text(self.accept_delay))
                      if self.accept_delay > 0 else "지금 바로 수락합니다")
            self._set_status(Status("매칭 잡힘!", detail, LEVEL_FOUND, queue))

        # 4) 지연 대기
        remaining = self._deadline - now
        if remaining > 0:
            self._set_status(Status("매칭 잡힘!", "{} 후 자동 수락".format(remaining_text(remaining)),
                                    LEVEL_FOUND, queue))
            return

        if self._answered:
            return

        # 5) 수락 직전 한 번 더 확인 (취소됐으면 요청하지 않는다)
        still_active = True
        try:
            confirm = self.conn.get_ready_check()
            if confirm is not None:
                c_state = confirm.get("state")
                c_response = confirm.get("playerResponse") or "None"
                if c_state == "InProgress" and c_response == "Accepted":
                    self._answered = True
                    self._emit_log("이미 수락된 매칭입니다.")
                    self._set_status(Status("수락 완료!", "다음 매칭을 기다립니다.", LEVEL_DONE, queue))
                    return
                if c_state not in ("InProgress", None) or c_response == "Declined":
                    still_active = False
        except NotFound:
            pass  # 리소스가 사라짐 → phase 로만 판단
        except (SessionExpired, NotConnected):
            self._reset_session()
            raise
        except LcuError:
            pass

        if not still_active:
            self._answered = True
            self._emit_log("매칭이 사라져 수락하지 않습니다.")
            self._set_status(Status("매칭 취소됨", "수락할 매칭이 없습니다.", LEVEL_WARN, queue))
            self._reset_session()
            return

        # 6) 수락
        try:
            ok = self.conn.accept_ready_check()
        except SessionExpired:
            self._reset_session()
            raise
        except NotConnected:
            self._reset_session()
            raise
        except LcuError as exc:
            self._answered = True
            self._emit_log("수락 요청이 실패했습니다. ({})".format(exc))
            return

        self._answered = True
        if ok:
            self.accept_count += 1
            self._emit("accepted", self.accept_count)
            self._emit_log("수락 완료! (누적 {}회)".format(self.accept_count))
            self._set_status(Status("수락 완료!", "다음 매칭을 기다립니다.", LEVEL_DONE, queue))
        else:
            self._emit_log("수락할 매칭이 이미 사라졌습니다.")
            self._set_status(Status("매칭 취소됨", "수락할 매칭이 없습니다.", LEVEL_WARN, queue))
        # 다음 매칭을 위해 세션은 남겨 두고, phase 가 벗어나면 초기화된다.

    # -- 무한 루프 ----------------------------------------------------------
    def wait_seconds(self):
        """다음 tick 까지 기다릴 시간. 지연 대기 중이면 그 시간에 맞춘다."""
        if not self.enabled:
            return IDLE_POLL_INTERVAL
        if self._in_session and self._deadline is not None:
            return max(0.02, min(POLL_INTERVAL, self._deadline - self._clock()))
        return POLL_INTERVAL

    def run_forever(self, stop_event=None):
        """GUI 스레드에서 도는 감시 루프."""
        stop = stop_event or self._stop
        while not stop.is_set():
            self.apply_commands()
            try:
                self.tick()
            except Exception as exc:  # 어떤 경우에도 앱은 살아 있어야 한다
                self._emit_log("알 수 없는 오류: {}".format(exc))
            self._wake.wait(self.wait_seconds())
            self._wake.clear()
