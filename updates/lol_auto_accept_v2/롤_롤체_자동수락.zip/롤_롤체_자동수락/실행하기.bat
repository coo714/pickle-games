@echo off
rem  Thin ASCII wrapper for the familiar Korean file name.
rem  All real logic lives in run.bat (pure ASCII + CRLF).
call "%~dp0run.bat"
