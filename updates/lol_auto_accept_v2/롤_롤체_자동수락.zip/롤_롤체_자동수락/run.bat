@echo off
rem ===================================================================
rem  LoL / TFT Auto Accept v2.2 - launcher (no console window)
rem  This file is pure ASCII with CRLF line endings on purpose.
rem  Korean text, a UTF-8 BOM, a code page switch, or LF-only line
rem  breaks make cmd.exe misread the commands on some Windows PCs.
rem ===================================================================
setlocal
set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"
cd /d "%~dp0"

rem 1) py launcher, windowless (pyw.exe -3)
where pyw.exe >nul 2>nul
if not errorlevel 1 (
    start "" pyw.exe -3 "%~dp0app.pyw"
    exit /b 0
)

rem 2) pythonw.exe
where pythonw.exe >nul 2>nul
if not errorlevel 1 (
    start "" pythonw.exe "%~dp0app.pyw"
    exit /b 0
)

rem 3) py -3 (console build of the launcher)
where py.exe >nul 2>nul
if not errorlevel 1 (
    start "" py.exe -3 "%~dp0app.pyw"
    exit /b 0
)

rem 4) python.exe
where python.exe >nul 2>nul
if not errorlevel 1 (
    start "" python.exe "%~dp0app.pyw"
    exit /b 0
)

rem 5) nothing found - ASCII only guidance
echo.
echo  ============================================================
echo   Python was not found on this PC.
echo  ============================================================
echo.
echo   1) Install Python 3 from https://www.python.org/downloads/
echo   2) On the first screen tick "Add python.exe to PATH"
echo   3) Then double-click this file again
echo.
echo   If Python is already installed, run diagnose.bat to see
echo   the error message.
echo.
pause
exit /b 1
