# -*- coding: utf-8 -*-
"""디스코드 음성방 자동 입장기 PRO — 단위 테스트.

실행:  python -m unittest discover -s tests -v
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import sys
import tempfile
import unittest
import unittest.mock
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import app as A  # noqa: E402

GUILD = "1234567890123456789"
CHANNEL = "9876543210987654321"
HTTPS_LINK = "https://discord.com/channels/{}/{}".format(GUILD, CHANNEL)
DEEP_LINK = "discord://discord.com/channels/{}/{}".format(GUILD, CHANNEL)


def decode_vb(expr: str) -> str:
    """VBS 식(ChrW + 리터럴)을 실제 문자열로 되돌립니다 (생성기 검증용)."""
    out = []
    position = 0
    token = re.compile(r"ChrW\(&H([0-9A-Fa-f]+)\)|\"((?:[^\"]|\"\")*)\"")
    for match in token.finditer(expr):
        if match.start() != position:
            gap = expr[position:match.start()].strip()
            assert gap in ("&", ""), "예상하지 못한 식: {!r}".format(gap)
        position = match.end()
        if match.group(1):
            out.append(chr(int(match.group(1), 16)))
        else:
            out.append(match.group(2).replace('""', '"'))
    tail = expr[position:].strip()
    assert tail in ("",), "남은 식: {!r}".format(tail)
    return "".join(out)


class LinkTests(unittest.TestCase):
    def test_standard_https_link(self):
        self.assertEqual(A.normalize_link(HTTPS_LINK), DEEP_LINK)

    def test_https_variants(self):
        for host in ("ptb.discord.com", "canary.discord.com", "discordapp.com"):
            url = "https://{}/channels/{}/{}".format(host, GUILD, CHANNEL)
            self.assertEqual(A.normalize_link(url), DEEP_LINK)

    def test_deep_link_passthrough(self):
        self.assertEqual(A.normalize_link(DEEP_LINK), DEEP_LINK)

    def test_deep_link_discordapp_host(self):
        url = "discord://discordapp.com/channels/{}/{}".format(GUILD, CHANNEL)
        self.assertEqual(A.normalize_link(url), DEEP_LINK)

    def test_deep_link_without_host(self):
        url = "discord://-/channels/{}/{}".format(GUILD, CHANNEL)
        self.assertEqual(A.normalize_link(url), DEEP_LINK)

    def test_strips_quotes_and_brackets(self):
        self.assertEqual(A.normalize_link('  "<{}>"  '.format(HTTPS_LINK)), DEEP_LINK)

    def test_surrounding_words_are_ignored(self):
        self.assertEqual(A.normalize_link(HTTPS_LINK + " 붙여넣기"), DEEP_LINK)

    def test_scheme_is_added_when_missing(self):
        url = "discord.com/channels/{}/{}".format(GUILD, CHANNEL)
        self.assertEqual(A.normalize_link(url), DEEP_LINK)

    def test_invite_link_rejected(self):
        with self.assertRaises(A.LinkError) as ctx:
            A.normalize_link("https://discord.gg/abcdef")
        self.assertIn("초대 링크", str(ctx.exception))

    def test_invite_path_rejected(self):
        with self.assertRaises(A.LinkError):
            A.normalize_link("https://discord.com/invite/abcdef")

    def test_missing_channel_segment_rejected(self):
        with self.assertRaises(A.LinkError) as ctx:
            A.normalize_link("https://discord.com/channels/{}".format(GUILD))
        self.assertIn("서버 ID와 채널 ID", str(ctx.exception))

    def test_extra_segments_rejected(self):
        with self.assertRaises(A.LinkError):
            A.normalize_link(HTTPS_LINK + "/extra")

    def test_non_numeric_ids_rejected(self):
        with self.assertRaises(A.LinkError):
            A.normalize_link("https://discord.com/channels/abc/def")

    def test_empty_link_rejected(self):
        with self.assertRaises(A.LinkError):
            A.normalize_link("   ")

    def test_other_domain_rejected(self):
        with self.assertRaises(A.LinkError):
            A.normalize_link("https://example.com/channels/{}/{}".format(GUILD, CHANNEL))

    def test_unknown_scheme_rejected(self):
        with self.assertRaises(A.LinkError):
            A.normalize_link("steam://run/730")

    def test_split_and_web_link(self):
        self.assertEqual(A.split_link(DEEP_LINK), (GUILD, CHANNEL))
        self.assertEqual(A.web_link(DEEP_LINK), HTTPS_LINK)
        self.assertEqual(A.split_link("discord://discord.com"), ("", ""))

    def test_short_link(self):
        self.assertEqual(A.short_link(DEEP_LINK), "서버 {} · 채널 {}".format(GUILD, CHANNEL))


class PresetTests(unittest.TestCase):
    def test_default_presets(self):
        presets = A.default_presets()
        self.assertEqual(len(presets), 3)
        self.assertEqual(presets[0]["name"], "1번 롤방")
        self.assertEqual(presets[2]["name"], "3번 배그방")
        self.assertTrue(all(item["link"] == "" for item in presets))

    def test_normalize_presets_pads_to_three(self):
        for raw in (None, [], [{"name": "방", "link": ""}],
                    [{"name": "a", "link": ""}, {"name": "b", "link": ""},
                     {"name": "c", "link": ""}, {"name": "d", "link": ""}]):
            presets = A.normalize_presets(raw)
            self.assertEqual(len(presets), 3)
            self.assertTrue(all("name" in item and "link" in item for item in presets))

    def test_normalize_presets_converts_https_link(self):
        presets = A.normalize_presets([{"name": "롤방", "link": HTTPS_LINK}])
        self.assertEqual(presets[0]["link"], DEEP_LINK)

    def test_normalize_presets_drops_invalid_link(self):
        presets = A.normalize_presets([{"name": "롤방", "link": "https://discord.gg/zzz"}])
        self.assertEqual(presets[0]["link"], "")

    def test_clean_preset_name(self):
        self.assertEqual(A.clean_preset_name("", 1), "2번 수다방")
        self.assertEqual(A.clean_preset_name("   ", 0), "1번 롤방")
        self.assertEqual(A.clean_preset_name("  롤방  ", 1), "롤방")
        self.assertEqual(len(A.clean_preset_name("가" * 40, 0)), A.PRESET_NAME_MAX)

    def test_activate_preset_switches_link(self):
        config = A.default_config()
        config["presets"][0]["link"] = DEEP_LINK
        other = "discord://discord.com/channels/{}/{}".format("1" * 18, "2" * 18)
        config["presets"][2]["link"] = other
        config = A.activate_preset(config, 2)
        self.assertEqual(A.active_index(config), 2)
        self.assertEqual(A.active_link(config), other)
        config = A.activate_preset(config, 0)
        self.assertEqual(A.active_link(config), DEEP_LINK)

    def test_activate_preset_clamps_index(self):
        self.assertEqual(A.active_index(A.activate_preset(A.default_config(), 9)), 2)
        self.assertEqual(A.active_index(A.activate_preset(A.default_config(), -5)), 0)
        self.assertEqual(A.active_index({"active_preset": "이상한값"}), 0)

    def test_active_preset_names(self):
        config = A.activate_preset(A.default_config(), 1)
        self.assertEqual(A.active_preset(config)["name"], "2번 수다방")


class ConfigTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.tmp = Path(self._tmp.name)

    def tearDown(self):
        self._tmp.cleanup()

    def test_default_config_shape(self):
        config = A.default_config()
        self.assertEqual(config["version"], 2)
        self.assertEqual(len(config["presets"]), 3)
        self.assertEqual(config["schedule"]["mode"], "always")
        self.assertEqual(config["game"], {"enabled": False, "path": "", "args": ""})
        self.assertTrue(config["mic_notice"])

    def test_save_and_load_roundtrip(self):
        config = A.default_config()
        config["presets"][1]["name"] = "수다방 A"
        config["presets"][1]["link"] = DEEP_LINK
        config["active_preset"] = 1
        config["schedule"] = {"mode": "window", "weekdays": [True, True, False, True, False, True, False],
                              "start": "20:30", "end": "01:00"}
        config["game"] = {"enabled": True, "path": "C:\\Games\\a.exe"}
        config["mic_notice"] = False
        path = A.save_config(config, self.tmp / "config.json")
        self.assertTrue(path.exists())
        loaded = A.load_config(path)
        self.assertEqual(loaded["active_preset"], 1)
        self.assertEqual(loaded["presets"][1]["name"], "수다방 A")
        self.assertEqual(loaded["presets"][1]["link"], DEEP_LINK)
        self.assertEqual(loaded["schedule"]["start"], "20:30")
        self.assertEqual(loaded["schedule"]["weekdays"],
                         [True, True, False, True, False, True, False])
        self.assertEqual(loaded["game"], {"enabled": True, "path": "C:\\Games\\a.exe", "args": ""})
        self.assertFalse(loaded["mic_notice"])
        with open(path, encoding="utf-8") as fp:
            raw = json.load(fp)
        self.assertEqual(raw["app"], A.APP_DIR_NAME)
        self.assertIn("presets", raw)

    def test_save_leaves_no_temp_file(self):
        A.save_config(A.default_config(), self.tmp / "config.json")
        self.assertEqual([p.name for p in self.tmp.iterdir()], ["config.json"])

    def test_load_broken_json_falls_back(self):
        path = self.tmp / "config.json"
        path.write_text("{이건 json 아님", encoding="utf-8")
        self.assertEqual(A.load_config(path), A.default_config())

    def test_load_missing_file_falls_back(self):
        self.assertEqual(A.load_config(self.tmp / "none.json"), A.default_config())

    def test_load_v1_config_migrates_link(self):
        path = self.tmp / "config.json"
        path.write_text(json.dumps({"link": HTTPS_LINK, "wait_seconds": 20}), encoding="utf-8")
        config = A.load_config(path)
        self.assertEqual(config["presets"][0]["link"], DEEP_LINK)
        self.assertEqual(config["active_preset"], 0)
        self.assertEqual(config["wait_seconds"], 20)

    def test_normalize_config_handles_junk(self):
        self.assertEqual(A.normalize_config(None), A.default_config())
        self.assertEqual(A.normalize_config([1, 2, 3]), A.default_config())
        config = A.normalize_config({"schedule": "??", "game": 5, "presets": "no"})
        self.assertEqual(config["schedule"], A.default_schedule())
        self.assertEqual(config["game"], {"enabled": False, "path": "", "args": ""})
        self.assertEqual(len(config["presets"]), 3)

    def test_game_disabled_without_path(self):
        config = A.normalize_config({"game": {"enabled": True, "path": ""}})
        self.assertFalse(config["game"]["enabled"])

    def test_wait_seconds_clamped(self):
        self.assertEqual(A.normalize_config({"wait_seconds": 9999})["wait_seconds"],
                         A.DEFAULT_WAIT_SECONDS)
        self.assertEqual(A.normalize_config({"wait_seconds": "x"})["wait_seconds"],
                         A.DEFAULT_WAIT_SECONDS)
        self.assertEqual(A.normalize_config({"wait_seconds": 30})["wait_seconds"], 30)


class ScheduleTests(unittest.TestCase):
    def build(self, start, end, weekdays=(True, True, True, True, True, False, False),
              mode="window"):
        return {"mode": mode, "weekdays": list(weekdays), "start": start, "end": end}

    def test_parse_time_formats(self):
        self.assertEqual(A.parse_time("19:00"), 19 * 60)
        self.assertEqual(A.parse_time("19시"), 19 * 60)
        self.assertEqual(A.parse_time("19시 30분"), 19 * 60 + 30)
        self.assertEqual(A.parse_time("24:00"), 1440)
        self.assertEqual(A.parse_time("0:00"), 0)
        self.assertEqual(A.parse_time("9"), 9 * 60)
        self.assertEqual(A.parse_time("19.30"), 19 * 60 + 30)

    def test_parse_time_rejects_bad_values(self):
        for bad in ("", "25:00", "19:70", "abc", "24:30", "-1:00"):
            with self.assertRaises(A.TimeFormatError, msg=bad):
                A.parse_time(bad)

    def test_format_minutes(self):
        self.assertEqual(A.format_minutes(0), "00:00")
        self.assertEqual(A.format_minutes(1440), "24:00")
        self.assertEqual(A.format_minutes(19 * 60), "19:00")
        self.assertEqual(A.format_minutes(2000), "24:00")

    def test_always_mode_ignores_time(self):
        schedule = self.build("19:00", "24:00", mode="always")
        for hour in (0, 6, 12, 23):
            self.assertTrue(A.should_join_now(datetime(2026, 11, 28, hour, 0), schedule))

    def test_window_inside_weekday(self):
        schedule = self.build("19:00", "24:00")
        self.assertTrue(A.should_join_now(datetime(2026, 11, 27, 19, 0), schedule))   # 금
        self.assertTrue(A.should_join_now(datetime(2026, 11, 27, 23, 59), schedule))

    def test_window_outside_weekday(self):
        schedule = self.build("19:00", "24:00")
        self.assertFalse(A.should_join_now(datetime(2026, 11, 27, 18, 59), schedule))
        self.assertFalse(A.should_join_now(datetime(2026, 11, 27, 12, 0), schedule))

    def test_window_weekend_excluded(self):
        schedule = self.build("19:00", "24:00")
        self.assertFalse(A.should_join_now(datetime(2026, 11, 28, 20, 0), schedule))  # 토

    def test_weekend_only(self):
        schedule = self.build("10:00", "12:00", weekdays=(False,) * 5 + (True, True))
        self.assertTrue(A.should_join_now(datetime(2026, 11, 28, 10, 30), schedule))
        self.assertFalse(A.should_join_now(datetime(2026, 11, 27, 10, 30), schedule))

    def test_overnight_window_before_midnight(self):
        schedule = self.build("22:00", "02:00")
        self.assertTrue(A.should_join_now(datetime(2026, 11, 27, 22, 30), schedule))  # 금
        self.assertFalse(A.should_join_now(datetime(2026, 11, 27, 21, 30), schedule))

    def test_overnight_window_after_midnight_uses_previous_day(self):
        schedule = self.build("22:00", "02:00")
        self.assertTrue(A.should_join_now(datetime(2026, 11, 28, 1, 0), schedule))    # 토 01시 = 금요일 밤
        self.assertFalse(A.should_join_now(datetime(2026, 11, 29, 1, 0), schedule))   # 일 01시 = 토요일 밤

    def test_overnight_ignores_until_after_start(self):
        schedule = self.build("22:00", "02:00")
        self.assertFalse(A.should_join_now(datetime(2026, 11, 27, 3, 0), schedule))

    def test_same_start_and_end_means_all_day(self):
        schedule = self.build("09:00", "09:00")
        self.assertTrue(A.should_join_now(datetime(2026, 11, 27, 4, 0), schedule))
        self.assertFalse(A.should_join_now(datetime(2026, 11, 28, 4, 0), schedule))

    def test_end_at_midnight_boundary(self):
        schedule = self.build("19:00", "24:00")
        self.assertTrue(A.should_join_now(datetime(2026, 11, 27, 23, 59), schedule))
        self.assertFalse(A.should_join_now(datetime(2026, 11, 28, 0, 0), schedule))

    def test_normalize_schedule_junk(self):
        self.assertEqual(A.normalize_schedule(None), A.default_schedule())
        schedule = A.normalize_schedule({"mode": "??", "start": "??", "end": "25:00",
                                         "weekdays": [1, 0]})
        self.assertEqual(schedule["mode"], "always")
        self.assertEqual(schedule["start"], "19:00")
        self.assertEqual(schedule["end"], "24:00")
        self.assertEqual(len(schedule["weekdays"]), 7)

    def test_normalize_schedule_trim_cache(self):
        schedule = A.normalize_schedule({"mode": "window", "start": "19시", "end": "24시"})
        self.assertEqual(schedule, {"mode": "window", "weekdays": [True] * 5 + [False] * 2,
                                    "start": "19:00", "end": "24:00"})

    def test_weekday_mask(self):
        self.assertEqual(A.weekday_mask([True] * 5 + [False] * 2), 0b0011111)
        self.assertEqual(A.weekday_mask([False] * 7), 0)
        self.assertEqual(A.weekday_mask([True] * 7), 0b1111111)

    def test_schedule_summary(self):
        self.assertEqual(A.schedule_summary(self.build("19:00", "24:00", mode="always")),
                         "컴 켜질 때 항상 입장")
        self.assertEqual(A.schedule_summary(self.build("19:00", "24:00")),
                         "평일 19:00~24:00 자동 입장")
        self.assertEqual(A.schedule_summary(self.build("10:00", "12:00", weekdays=[True] * 7)),
                         "매일 10:00~12:00 자동 입장")
        self.assertEqual(A.schedule_summary(
            self.build("10:00", "12:00", weekdays=[False] * 5 + [True, True])),
            "주말 10:00~12:00 자동 입장")
        self.assertEqual(A.schedule_summary(
            self.build("09:00", "10:00", weekdays=[True, False, True, False, False, False, False])),
            "월수 09:00~10:00 자동 입장")

    def test_schedule_state_text(self):
        schedule = self.build("19:00", "24:00")
        self.assertEqual(A.schedule_state_text(datetime(2026, 11, 27, 20, 0), schedule),
                         "지금은 입장 시간이에요")
        self.assertEqual(A.schedule_state_text(datetime(2026, 11, 27, 8, 0), schedule),
                         "지금은 예약 시간 밖이에요")


class GameTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.tmp = Path(self._tmp.name)

    def tearDown(self):
        self._tmp.cleanup()

    def make(self, name):
        path = self.tmp / name
        path.write_bytes(b"MZ")
        return str(path)

    def test_executable_accepted(self):
        self.assertTrue(A.validate_program_path(self.make("game.exe")))

    def test_shortcut_accepted(self):
        self.assertTrue(A.validate_program_path(self.make("롤.lnk")))

    def test_quoted_path_accepted(self):
        self.assertTrue(A.validate_program_path('"{}"'.format(self.make("a.exe"))))

    def test_wrong_extension_rejected(self):
        self.assertFalse(A.validate_program_path(self.make("note.txt")))

    def test_missing_file_rejected(self):
        self.assertFalse(A.validate_program_path(str(self.tmp / "none.exe")))

    def test_empty_rejected(self):
        self.assertFalse(A.validate_program_path(""))
        self.assertFalse(A.validate_program_path(None))

    def test_program_name(self):
        self.assertEqual(A.program_name("C:\\Riot Games\\LeagueClient.exe"), "LeagueClient.exe")
        self.assertEqual(A.program_name('"C:\\a\\b.lnk"'), "b.lnk")
        self.assertEqual(A.program_name(""), "")


class StartupTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.tmp = Path(self._tmp.name)
        self.startup = self.tmp / "Startup"
        self.config = A.default_config()
        self.config["presets"][0]["link"] = DEEP_LINK
        self.config["active_preset"] = 0

    def tearDown(self):
        self._tmp.cleanup()

    def test_vbs_contains_link_and_fallback(self):
        text = A.build_startup_vbs(self.config)
        self.assertIn('deepLink = "{}"'.format(DEEP_LINK), text)
        self.assertIn('webLink = "{}"'.format(HTTPS_LINK), text)
        self.assertIn("Discord.exe", text)

    def test_vbs_always_mode(self):
        text = A.build_startup_vbs(self.config)
        self.assertIn("useWindow = False", text)

    def test_vbs_window_mode_constants(self):
        self.config["schedule"] = A.normalize_schedule(
            {"mode": "window", "start": "19:00", "end": "24:00",
             "weekdays": [True, True, True, True, True, False, False]})
        text = A.build_startup_vbs(self.config)
        self.assertIn("useWindow = True", text)
        self.assertIn("startM = 1140", text)
        self.assertIn("endM = 1440", text)
        self.assertIn("dayMask = 31", text)

    def test_vbs_overnight_constants(self):
        self.config["schedule"] = A.normalize_schedule(
            {"mode": "window", "start": "22:00", "end": "02:00",
             "weekdays": [False, True, False, False, False, False, False]})
        text = A.build_startup_vbs(self.config)
        self.assertIn("startM = 1320", text)
        self.assertIn("endM = 120", text)
        self.assertIn("dayMask = 2", text)

    def test_vbs_uses_active_preset_only(self):
        other = "discord://discord.com/channels/{}/{}".format("3" * 18, "4" * 18)
        self.config["presets"][1]["link"] = other
        self.config["active_preset"] = 1
        text = A.build_startup_vbs(self.config)
        self.assertIn(other, text)
        self.assertNotIn(DEEP_LINK, text)

    def test_vbs_game_line_only_when_enabled(self):
        self.assertNotIn("launch the game", A.build_startup_vbs(self.config))
        self.config["game"] = {"enabled": True, "path": "C:\\Games\\배그.exe"}
        text = A.build_startup_vbs(self.config)
        self.assertIn("launch the game", text)
        self.assertIn("Chr(34) & gamePath & Chr(34)", text)
        line = [l for l in text.splitlines() if l.startswith("gamePath = ")][0]
        self.assertEqual(decode_vb(line.split("=", 1)[1].strip()), "C:\\Games\\배그.exe")

    def test_vbs_game_line_dropped_when_disabled(self):
        self.config["game"] = {"enabled": False, "path": "C:\\Games\\x.exe"}
        self.assertNotIn("launch the game", A.build_startup_vbs(self.config))

    def test_vbs_mic_popup_toggle(self):
        self.config["mic_notice"] = True
        text = A.build_startup_vbs(self.config)
        self.assertIn("shell.Popup msg, 4", text)
        self.config["mic_notice"] = False
        self.assertNotIn("shell.Popup msg, 4", A.build_startup_vbs(self.config))

    def test_vb_expression_encodes_korean(self):
        text = "입장 완료! 마이크 Ctrl+Shift+M"
        expr = A.vb_expression(text)
        self.assertNotIn("입", expr)
        self.assertIn('" Ctrl+Shift+M"', expr)
        self.assertEqual(decode_vb(expr), text)
        self.assertTrue(expr.isascii())

    def test_vbs_mic_message_decodes(self):
        text = A.build_startup_vbs(self.config)
        line = [l for l in text.splitlines() if l.strip().startswith("msg = ")][0]
        self.assertEqual(decode_vb(line.split("=", 1)[1].strip()), A.MIC_NOTICE_TEXT)
    def test_vbs_is_ascii_only(self):
        self.config["game"] = {"enabled": True, "path": "C:\\Games\\배그.exe"}
        self.config["mic_notice"] = True
        text = A.build_startup_vbs(self.config)
        self.assertTrue(text.isascii(), "VBS 파일은 순수 ASCII 여야 합니다")

    def test_vbs_blocks_balanced(self):
        self.config["schedule"]["mode"] = "window"
        self.config["game"] = {"enabled": True, "path": "C:\\Games\\x.exe"}
        text = A.build_startup_vbs(self.config)
        lines = [line.strip() for line in text.splitlines()]
        block_ifs = [l for l in lines if re.match(r"^If .* Then$", l)
                     or re.match(r"^ElseIf .* Then$", l)]
        end_ifs = [l for l in lines if l == "End If"]
        # If 블록 수 = End If 수 (ElseIf 는 같은 블록에 붙음)
        self.assertEqual(len([l for l in block_ifs if l.startswith("If ")]), len(end_ifs))
        self.assertEqual(len([l for l in lines if l.startswith("For ")]),
                         len([l for l in lines if l == "Next"]))
        self.assertIn("If inWin Then", text)

    def test_vbs_requires_active_link(self):
        with self.assertRaises(A.LinkError):
            A.build_startup_vbs(A.default_config())

    def test_enable_disable_cycle(self):
        path = A.enable_startup(self.startup, self.config)
        self.assertTrue(path.exists())
        self.assertTrue(A.is_startup_enabled(self.startup))
        self.assertEqual(A.registered_link(self.startup), DEEP_LINK)
        self.assertTrue(A.disable_startup(self.startup))
        self.assertFalse(A.is_startup_enabled(self.startup))
        self.assertFalse(A.disable_startup(self.startup))

    def test_enable_overwrites_with_new_link(self):
        A.enable_startup(self.startup, self.config)
        new_link = "discord://discord.com/channels/{}/{}".format("5" * 18, "6" * 18)
        self.config["presets"][0]["link"] = new_link
        A.enable_startup(self.startup, self.config)
        self.assertEqual(A.registered_link(self.startup), new_link)
        files = [p.name for p in self.startup.iterdir()]
        self.assertEqual(files, [A.STARTUP_FILENAME])

    def test_startup_script_path(self):
        self.assertEqual(A.startup_script_path(self.startup).name, "DiscordAutoVoice.vbs")

    def test_registered_link_missing_file(self):
        self.assertIsNone(A.registered_link(self.startup))


class GameSearchTests(unittest.TestCase):
    """롤·롤체 자동 찾기 (바로가기 → 라이엇 클라이언트 순서)."""

    ENV = {
        "PUBLIC": "C:\\Users\\Public",
        "USERPROFILE": "C:\\Users\\june",
        "OneDrive": "C:\\Users\\june\\OneDrive",
        "ProgramData": "C:\\ProgramData",
        "SystemDrive": "C:",
    }
    LOL_URL = "C:\\Users\\Public\\Desktop\\League of Legends.url"
    TFT_LNK = ("C:\\ProgramData\\Microsoft\\Windows\\Start Menu\\Programs"
               "\\Riot Games\\Teamfight Tactics.lnk")
    RIOT_ON_D = "D:\\Riot Games\\Riot Client\\RiotClientServices.exe"

    def exists_in(self, *paths):
        wanted = {str(path).lower() for path in paths}
        return lambda path: str(path).lower() in wanted

    def test_search_dirs_order(self):
        dirs = A.game_search_dirs(self.ENV)
        self.assertEqual(dirs[0], "C:\\Users\\Public\\Desktop")
        self.assertEqual(dirs[1], "C:\\Users\\june\\Desktop")
        self.assertEqual(dirs[2], "C:\\Users\\june\\OneDrive\\Desktop")
        self.assertEqual(dirs[3], "C:\\Users\\june\\OneDrive\\바탕 화면")
        self.assertEqual(dirs[4], "C:\\ProgramData\\Microsoft\\Windows\\Start Menu"
                                   "\\Programs\\Riot Games")

    def test_search_dirs_are_deduped_with_empty_env(self):
        dirs = A.game_search_dirs({})
        self.assertEqual(len(dirs), len(set(dirs)))
        self.assertTrue(all(dirs))

    def test_riot_client_candidates_cover_drives_and_program_files(self):
        env = dict(self.ENV, ProgramFiles="C:\\Program Files")
        candidates = A.riot_client_candidates(env)
        self.assertEqual(candidates[0], "C:\\Riot Games\\Riot Client\\RiotClientServices.exe")
        self.assertIn(self.RIOT_ON_D, candidates)
        self.assertIn("C:\\Program Files\\Riot Games\\Riot Client\\RiotClientServices.exe",
                      candidates)
        self.assertEqual(len(candidates), len(set(candidates)))

    def test_detect_lol_public_desktop_shortcut(self):
        found = A.detect_game("lol", env=self.ENV, exists=self.exists_in(self.LOL_URL))
        self.assertEqual(found["path"], self.LOL_URL)
        self.assertEqual(found["args"], "")
        self.assertEqual(found["source"], "shortcut")
        self.assertEqual(found["kind"], "lol")

    def test_detect_tft_start_menu_shortcut(self):
        found = A.detect_game("tft", env=self.ENV, exists=self.exists_in(self.TFT_LNK))
        self.assertEqual(found["path"], self.TFT_LNK)
        self.assertEqual(found["args"], "")
        self.assertEqual(found["label"], "롤체(TFT)")

    def test_detect_shortcut_wins_over_riot_client(self):
        found = A.detect_game("lol", env=self.ENV,
                              exists=self.exists_in(self.LOL_URL, self.RIOT_ON_D))
        self.assertEqual(found["source"], "shortcut")
        self.assertEqual(found["path"], self.LOL_URL)

    def test_detect_lol_falls_back_to_riot_client_with_args(self):
        found = A.detect_game("lol", env=self.ENV, exists=self.exists_in(self.RIOT_ON_D))
        self.assertEqual(found["path"], self.RIOT_ON_D)
        self.assertEqual(found["source"], "riot_client")
        self.assertEqual(found["args"],
                         "--launch-product=league_of_legends --launch-patchline=live")

    def test_detect_tft_falls_back_to_riot_client_with_args(self):
        found = A.detect_game("롤체", env=self.ENV, exists=self.exists_in(self.RIOT_ON_D))
        self.assertEqual(found["kind"], "tft")
        self.assertEqual(found["args"],
                         "--launch-product=teamfight_tactics --launch-patchline=live")

    def test_detect_not_found_message(self):
        with self.assertRaises(A.GameNotFoundError) as ctx:
            A.detect_game("lol", env=self.ENV, exists=lambda _p: False)
        message = str(ctx.exception)
        self.assertIn("찾지 못했어요", message)
        self.assertIn("League of Legends", message)
        self.assertIn("RiotClientServices", message)

    def test_detect_unknown_kind_defaults_to_lol(self):
        found = A.detect_game("??", env=self.ENV, exists=self.exists_in(self.LOL_URL))
        self.assertEqual(found["kind"], "lol")


class GameLaunchTests(unittest.TestCase):
    """실행 인자 전달 · LeagueClient.exe 보정 · 무콘솔 실행."""

    def test_split_args(self):
        self.assertEqual(A.split_args(""), [])
        self.assertEqual(A.split_args("--a=1   --b=2"), ["--a=1", "--b=2"])
        self.assertEqual(A.split_args('--x="a b"'), ["--x=a b"])

    def test_build_launch_argv_exe_with_args(self):
        argv = A.build_launch_argv(
            "C:\\Riot Games\\Riot Client\\RiotClientServices.exe",
            "--launch-product=league_of_legends --launch-patchline=live")
        self.assertEqual(argv, [
            "C:\\Riot Games\\Riot Client\\RiotClientServices.exe",
            "--launch-product=league_of_legends",
            "--launch-patchline=live",
        ])

    def test_build_launch_argv_shortcut_uses_shell_start(self):
        argv = A.build_launch_argv("C:\\Users\\Public\\Desktop\\League of Legends.lnk")
        self.assertEqual(argv[:4], ["cmd", "/c", "start", ""])
        self.assertEqual(argv[4], "C:\\Users\\Public\\Desktop\\League of Legends.lnk")

    def test_build_launch_argv_empty(self):
        self.assertEqual(A.build_launch_argv(""), [])
        self.assertEqual(A.build_launch_argv(None), [])

    def test_launch_game_is_windows_only(self):
        if os.name == "nt":
            self.skipTest("윈도우에서는 실제 실행 없이 확인할 수 없음")
        with self.assertRaises(OSError):
            A.launch_game("C:\\Games\\a.exe")

    def test_riot_product_for_client(self):
        self.assertEqual(A.riot_product_for_client("C:\\a\\LeagueClient.exe"), "lol")
        self.assertEqual(A.riot_product_for_client("C:\\a\\TFTClient.exe"), "tft")
        self.assertEqual(A.riot_product_for_client("C:\\a\\RiotClientServices.exe"), "")

    def test_resolve_game_launch_reroutes_league_client(self):
        client = "C:\\Riot Games\\Riot Client\\RiotClientServices.exe"
        exists = {client.lower()}
        path, args, changed = A.resolve_game_launch(
            "C:\\Riot Games\\League of Legends\\LeagueClient.exe",
            env={}, exists=lambda p: p.lower() in exists)
        self.assertTrue(changed)
        self.assertEqual(path, client)
        self.assertEqual(args, "--launch-product=league_of_legends --launch-patchline=live")

    def test_resolve_game_launch_reroutes_tft_client(self):
        client = "D:\\Riot Games\\Riot Client\\RiotClientServices.exe"
        exists = {client.lower()}
        path, args, changed = A.resolve_game_launch(
            "D:\\Riot Games\\Teamfight Tactics\\TFTClient.exe",
            env={}, exists=lambda p: p.lower() in exists)
        self.assertTrue(changed)
        self.assertEqual(path, client)
        self.assertIn("--launch-product=teamfight_tactics", args)

    def test_resolve_game_launch_keeps_client_when_no_riot_client(self):
        path, args, changed = A.resolve_game_launch(
            "C:\\Games\\LeagueClient.exe", env={}, exists=lambda _p: False)
        self.assertFalse(changed)
        self.assertEqual(path, "C:\\Games\\LeagueClient.exe")
        self.assertEqual(args, "")

    def test_resolve_game_launch_keeps_existing_args(self):
        path, args, changed = A.resolve_game_launch(
            "C:\\Games\\LeagueClient.exe", "--launch-product=league_of_legends",
            env={}, exists=lambda _p: True)
        self.assertFalse(changed)
        self.assertEqual(args, "--launch-product=league_of_legends")

    def test_resolve_game_launch_plain_exe_untouched(self):
        path, args, changed = A.resolve_game_launch(
            "C:\\Games\\battle.exe", env={}, exists=lambda _p: True)
        self.assertFalse(changed)
        self.assertEqual(path, "C:\\Games\\battle.exe")


class GameConfigTests(unittest.TestCase):
    """게임 설정의 path + args 저장."""

    def test_game_args_are_kept_for_exe(self):
        config = A.normalize_config({
            "game": {"enabled": True, "path": "C:\\Riot Games\\Riot Client\\RiotClientServices.exe",
                     "args": "--launch-product=league_of_legends --launch-patchline=live"}})
        self.assertEqual(config["game"]["args"],
                         "--launch-product=league_of_legends --launch-patchline=live")
        self.assertTrue(config["game"]["enabled"])

    def test_game_args_dropped_for_shortcut(self):
        config = A.normalize_config({
            "game": {"enabled": True, "path": "C:\\Users\\Public\\Desktop\\League of Legends.lnk",
                     "args": "--launch-product=league_of_legends"}})
        self.assertEqual(config["game"]["args"], "")

    def test_vbs_writes_launch_args(self):
        config = A.default_config()
        config["presets"][0]["link"] = DEEP_LINK
        config["game"] = {"enabled": True, "path": "C:\\Riot Games\\Riot Client\\RiotClientServices.exe",
                          "args": "--launch-product=league_of_legends --launch-patchline=live"}
        text = A.build_startup_vbs(config)
        line = [l for l in text.splitlines() if l.startswith("gameArgs = ")][0]
        self.assertEqual(decode_vb(line.split("=", 1)[1].strip()),
                         "--launch-product=league_of_legends --launch-patchline=live")
        self.assertIn('& " " & gameArgs', text)
        self.assertTrue(text.isascii())

    def test_vbs_without_args_still_builds(self):
        config = A.default_config()
        config["presets"][0]["link"] = DEEP_LINK
        config["game"] = {"enabled": True, "path": "C:\\Games\\배그.exe"}
        text = A.build_startup_vbs(config)
        self.assertIn("gameArgs = \"\"", text)
        self.assertIn("If Len(gameArgs) > 0 Then", text)
        lines = [l.strip() for l in text.splitlines()]
        self.assertEqual(len([l for l in lines if re.match(r"^If .* Then$", l)]),
                         len([l for l in lines if l == "End If"]))


class VersionTests(unittest.TestCase):
    def test_parse_version_forms(self):
        self.assertEqual(A.parse_version("1.2.0"), (1, 2, 0))
        self.assertEqual(A.parse_version("v1.2"), (1, 2, 0))
        self.assertEqual(A.parse_version(" 2 "), (2, 0, 0))
        self.assertEqual(A.parse_version("1.10.3"), (1, 10, 3))

    def test_parse_version_rejects_junk(self):
        for bad in ("", None, "abc", "1.2.x", "1..2", "1.2.3.4.5", "v"):
            with self.assertRaises(A.UpdateError, msg=repr(bad)):
                A.parse_version(bad)

    def test_is_newer_version(self):
        self.assertTrue(A.is_newer_version("1.3.0", "1.2.0"))
        self.assertTrue(A.is_newer_version("1.2.1", "1.2.0"))
        self.assertTrue(A.is_newer_version("v2", "1.9.9"))
        self.assertFalse(A.is_newer_version("1.2.0", "1.2.0"))
        self.assertFalse(A.is_newer_version("1.1.9", "1.2.0"))
        self.assertFalse(A.is_newer_version("이상한값", "1.2.0"))
        self.assertTrue(A.is_newer_version("1.10.0", "1.9.0"))  # 숫자 크기대로 비교

    def test_version_text(self):
        self.assertEqual(A.version_text("1.2.0"), "v1.2.0")
        self.assertEqual(A.version_text("v1.2.0"), "v1.2.0")
        self.assertEqual(A.version_text(A.APP_VERSION), "v1.2.2")


class ManifestTests(unittest.TestCase):
    GOOD = {
        "version": "1.3.0",
        "app_url": A.UPDATE_BASE_URL + "/app.py",
        "sha256": "a" * 64,
        "notes": "롤 자동 찾기 추가",
    }

    def test_parse_manifest_from_json_text(self):
        manifest = A.parse_manifest(json.dumps(self.GOOD))
        self.assertEqual(manifest["version"], "1.3.0")
        self.assertEqual(manifest["app_url"], self.GOOD["app_url"])
        self.assertEqual(manifest["sha256"], "a" * 64)
        self.assertEqual(manifest["notes"], "롤 자동 찾기 추가")

    def test_parse_manifest_from_bytes(self):
        manifest = A.parse_manifest(json.dumps(self.GOOD).encode("utf-8"))
        self.assertEqual(manifest["version"], "1.3.0")

    def test_parse_manifest_defaults(self):
        manifest = A.parse_manifest({"version": "1.3.0"})
        self.assertEqual(manifest["app_url"], A.UPDATE_APP_URL)
        self.assertEqual(manifest["sha256"], "")
        self.assertEqual(manifest["notes"], "")

    def test_parse_manifest_rejects_junk(self):
        for bad in ("{이건 json 아님", "[]", 5, None, {"version": ""}, {"version": "x"}):
            with self.assertRaises(A.UpdateError, msg=repr(bad)):
                A.parse_manifest(bad)

    def test_parse_manifest_rejects_insecure_url(self):
        with self.assertRaises(A.UpdateError):
            A.parse_manifest(dict(self.GOOD, app_url="http://example.com/x/app.py"))

    def test_parse_manifest_rejects_foreign_host(self):
        with self.assertRaises(A.UpdateError):
            A.parse_manifest(dict(self.GOOD, app_url="https://evil.example.com/app.py"))

    def test_parse_manifest_rejects_bad_sha(self):
        with self.assertRaises(A.UpdateError):
            A.parse_manifest(dict(self.GOOD, sha256="abc"))

    def test_check_for_update_newer(self):
        result = A.check_for_update("1.2.0", fetch=lambda _url: json.dumps(self.GOOD))
        self.assertEqual(result["version"], "1.3.0")

    def test_check_for_update_same_or_older(self):
        same = dict(self.GOOD, version="1.2.0")
        self.assertIsNone(A.check_for_update("1.2.0", fetch=lambda _u: json.dumps(same)))
        older = dict(self.GOOD, version="1.0.0")
        self.assertIsNone(A.check_for_update("1.2.0", fetch=lambda _u: json.dumps(older)))

    def test_check_for_update_network_error_is_silent(self):
        def boom(_url):
            raise OSError("인터넷 없음")
        self.assertIsNone(A.check_for_update("1.2.0", fetch=boom))

    def test_check_for_update_broken_json_is_silent(self):
        self.assertIsNone(A.check_for_update("1.2.0", fetch=lambda _u: "<html>404</html>"))


OLD_APP = '''# -*- coding: utf-8 -*-
APP_VERSION = "1.2.0"


def main(argv=None):
    return 0
'''

NEW_APP = '''# -*- coding: utf-8 -*-
"""new"""
APP_VERSION = "1.3.0"


def main(argv=None):
    return 0
'''


class UpdateInstallTests(unittest.TestCase):
    """SHA-256 · ast.parse 검증과 롤백."""

    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.tmp = Path(self._tmp.name)
        self.app_path = self.tmp / "app.py"
        self.app_path.write_text(OLD_APP, encoding="utf-8")
        self.config_file = self.tmp / "config.json"
        self.config_file.write_text('{"kept": true}', encoding="utf-8")
        self.sha = hashlib.sha256(NEW_APP.encode("utf-8")).hexdigest()

    def tearDown(self):
        self._tmp.cleanup()

    def manifest(self, sha=None, version="1.3.0"):
        return {"version": version, "app_url": A.UPDATE_APP_URL,
                "sha256": self.sha if sha is None else sha, "notes": "테스트"}

    def fetch(self, payload=NEW_APP):
        return lambda _url: payload.encode("utf-8") if isinstance(payload, str) else payload

    def test_verify_payload_accepts_good_file(self):
        digest = A.verify_update_payload(NEW_APP.encode("utf-8"), self.sha)
        self.assertEqual(digest, self.sha)

    def test_verify_payload_rejects_sha_mismatch(self):
        with self.assertRaises(A.UpdateError) as ctx:
            A.verify_update_payload(NEW_APP.encode("utf-8"), "0" * 64)
        self.assertIn("SHA-256", str(ctx.exception))

    def test_verify_python_source_rejects_syntax_error(self):
        with self.assertRaises(A.UpdateError):
            A.verify_python_source("def broken(:\n")

    def test_verify_python_source_rejects_other_program(self):
        with self.assertRaises(A.UpdateError):
            A.verify_python_source("print('hello')\n")

    def test_download_update_writes_verified_temp_file(self):
        path = A.download_update(self.manifest(), fetch=self.fetch(), app_path=self.app_path)
        self.assertTrue(path.exists())
        self.assertEqual(path.read_text(encoding="utf-8"), NEW_APP)
        self.assertEqual(path.parent, self.tmp)
        path.unlink()

    def test_download_update_rejects_sha_mismatch(self):
        with self.assertRaises(A.UpdateError):
            A.download_update(self.manifest(sha="0" * 64), fetch=self.fetch(),
                              app_path=self.app_path)
        self.assertEqual({p.name for p in self.tmp.iterdir()}, {"app.py", "config.json"})

    def test_perform_update_success_keeps_backup_and_config(self):
        result = A.perform_update(self.manifest(), self.app_path, fetch=self.fetch())
        self.assertEqual(self.app_path.read_text(encoding="utf-8"), NEW_APP)
        self.assertTrue(result["backup"].endswith("app.py.bak"))
        self.assertEqual(Path(result["backup"]).read_text(encoding="utf-8"), OLD_APP)
        self.assertEqual(self.config_file.read_text(encoding="utf-8"), '{"kept": true}')
        self.assertEqual(sorted(p.name for p in self.tmp.iterdir()),
                         ["app.py", "app.py.bak", "config.json"])

    def test_perform_update_sha_mismatch_leaves_original(self):
        with self.assertRaises(A.UpdateError):
            A.perform_update(self.manifest(sha="0" * 64), self.app_path, fetch=self.fetch())
        self.assertEqual(self.app_path.read_text(encoding="utf-8"), OLD_APP)
        self.assertFalse((self.tmp / "app.py.bak").exists())

    def test_perform_update_syntax_error_leaves_original(self):
        broken = 'APP_VERSION = "1.3.0"\n\ndef main(\n'
        with self.assertRaises(A.UpdateError):
            A.perform_update(self.manifest(sha=hashlib.sha256(broken.encode()).hexdigest()),
                             self.app_path, fetch=self.fetch(broken))
        self.assertEqual(self.app_path.read_text(encoding="utf-8"), OLD_APP)
        self.assertEqual({p.name for p in self.tmp.iterdir()}, {"app.py", "config.json"})

    def test_perform_update_missing_sha_still_parses_code(self):
        with self.assertRaises(A.UpdateError):
            A.perform_update(dict(self.manifest(), sha256=""), self.app_path,
                             fetch=self.fetch("not python"))
        self.assertEqual(self.app_path.read_text(encoding="utf-8"), OLD_APP)

    def test_install_update_rolls_back_when_replace_fails(self):
        new_file = self.tmp / "incoming.py"
        new_file.write_text(NEW_APP, encoding="utf-8")
        with unittest.mock.patch.object(A.os, "replace", side_effect=OSError("잠김")):
            with self.assertRaises(A.UpdateError) as ctx:
                A.install_update(new_file, self.app_path)
        self.assertIn("되돌렸", str(ctx.exception))
        self.assertEqual(self.app_path.read_text(encoding="utf-8"), OLD_APP)
        self.assertFalse((self.tmp / "app.py.new").exists())

    def test_install_update_rejects_bad_staged_content(self):
        new_file = self.tmp / "incoming.py"
        new_file.write_text("def nope(:\n", encoding="utf-8")
        with self.assertRaises(A.UpdateError):
            A.install_update(new_file, self.app_path)
        self.assertEqual(self.app_path.read_text(encoding="utf-8"), OLD_APP)

    def test_restart_application_argv(self):
        calls = []
        argv = A.restart_application(self.app_path, python_executable="/usr/bin/python3",
                                     popen=lambda args, **kwargs: calls.append((args, kwargs)),
                                     exists=lambda _p: False)
        self.assertEqual(argv, ["/usr/bin/python3", str(self.app_path.resolve())])
        self.assertEqual(calls[0][0], argv)
        self.assertEqual(calls[0][1]["cwd"], str(self.tmp.resolve()))


if __name__ == "__main__":
    unittest.main(verbosity=2)
