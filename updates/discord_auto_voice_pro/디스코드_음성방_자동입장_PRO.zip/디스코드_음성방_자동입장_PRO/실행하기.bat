@echo off
rem ===================================================================
rem  Discord Auto Voice PRO - launcher (no console window)
rem  Pure ASCII + CRLF on purpose: Korean text, a UTF-8 BOM, a code
rem  page switch, or LF-only line breaks make cmd.exe misread the
rem  commands on some Windows PCs.
rem ===================================================================
setlocal
set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"
cd /d "%~dp0"

rem 1) windowless python: pyw -3
set "PYW="
where pyw.exe >nul 2>nul
if not errorlevel 1 (
    pyw.exe -3 -c "import sys" >nul 2>nul
    if not errorlevel 1 set "PYW=pyw.exe -3"
)
if defined PYW goto run_quiet

rem 2) windowless python: pythonw
where pythonw.exe >nul 2>nul
if not errorlevel 1 set "PYW=pythonw.exe"
if defined PYW goto run_quiet

rem 3) console python (only one window shows)
set "PYCMD="
where py.exe >nul 2>nul
if not errorlevel 1 (
    py.exe -3 -c "import sys" >nul 2>nul
    if not errorlevel 1 set "PYCMD=py.exe -3"
)
if defined PYCMD goto run_console

where python.exe >nul 2>nul
if not errorlevel 1 set "PYCMD=python.exe"
if not defined PYCMD goto no_python

:run_console
%PYCMD% "%~dp0app.py"
if errorlevel 1 goto failed
goto end

:run_quiet
start "" %PYW% "%~dp0app.py"
exit /b 0

:failed
echo.
echo  [info] The program stopped with an error. See the message above.
pause
goto end

:no_python
echo.
echo  [info] Python was not found on this PC.
echo.
echo   1. Install Python 3 from https://www.python.org/downloads/
echo   2. Tick "Add python.exe to PATH" on the first screen
echo   3. Then double-click this file again
echo.
pause

:end
endlocal
