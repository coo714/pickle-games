/* 네이버 연관 키워드 검색량 — background service worker (Manifest V3)
 *
 * search.naver.com 페이지에서 api.searchad.naver.com 을 직접 부르면 CORS에 막히므로
 * host_permissions를 가진 이 워커가 대신 호출한다.
 * 네이버 검색광고 API 서명: HMAC-SHA256("{timestamp}.GET./keywordstool", secret) → Base64
 */
importScripts('lib/keyword-logic.js');

var LOGIC = NaverKeywordLogic;
var STORAGE_KEY = 'nkbKeys';
var REQUEST_TIMEOUT_MS = 15000;
var AUTOCOMPLETE_TIMEOUT_MS = 5000;
var EXTRA_TIMEOUT_MS = 8000;
var CACHE_TTL_MS = 30 * 60 * 1000;
var LIMIT = LOGIC.DEFAULT_LIMIT;

var cache = new Map();

function getKeys() {
  return new Promise(function (resolve) {
    chrome.storage.local.get(STORAGE_KEY, function (result) {
      var keys = result && result[STORAGE_KEY];
      resolve(keys && typeof keys === 'object' ? keys : null);
    });
  });
}

function makeSignature(timestamp, method, path, secretKey) {
  return LOGIC.hmacSha256Base64(secretKey, LOGIC.signatureBase(timestamp, method, path));
}

function mapHttpError(status, detail) {
  var suffix = detail ? ' — ' + detail : '';
  if (status === 401 || status === 403) {
    return {
      code: 'auth',
      message: 'API 키 인증에 실패했습니다. Customer ID · API Key · Secret Key를 다시 확인해 주세요.' + suffix
    };
  }
  if (status === 429) {
    return {
      code: 'quota',
      message: '호출 한도를 초과했습니다. 잠시 후 다시 시도해 주세요.' + suffix
    };
  }
  if (status === 400) {
    return {
      code: 'request',
      message: '검색광고 API가 요청을 거부했습니다. 검색어를 확인해 주세요.' + suffix
    };
  }
  return { code: 'http', message: '검색광고 API 오류 (HTTP ' + status + ')' + suffix };
}

async function readErrorDetail(response) {
  try {
    var text = await response.text();
    if (!text) return '';
    try {
      var data = JSON.parse(text);
      return String(data.detail || data.message || data.title || data.error || '').slice(0, 200);
    } catch (e) {
      return String(text).replace(/\s+/g, ' ').trim().slice(0, 200);
    }
  } catch (e) {
    return '';
  }
}

/* keywordstool 한 번 호출 → { ok, keywordList, error? } */
async function callKeywordTool(url, keys, timeoutMs) {
  var timestamp = String(Date.now());
  var signature;
  try {
    signature = await makeSignature(timestamp, 'GET', LOGIC.KEYWORD_TOOL_PATH, keys.secretKey);
  } catch (err) {
    return { ok: false, keywordList: [], error: { code: 'sign', message: '서명 생성에 실패했습니다: ' + (err && err.message ? err.message : err) } };
  }

  var controller = new AbortController();
  var limit = typeof timeoutMs === 'number' && timeoutMs > 0 ? timeoutMs : REQUEST_TIMEOUT_MS;
  var timer = setTimeout(function () { controller.abort(); }, limit);

  try {
    var response = await fetch(url, {
      method: 'GET',
      headers: LOGIC.buildRequestHeaders(keys, timestamp, signature),
      credentials: 'omit',
      cache: 'no-store',
      signal: controller.signal
    });

    if (!response.ok) {
      var detail = await readErrorDetail(response);
      return { ok: false, keywordList: [], error: mapHttpError(response.status, detail), status: response.status };
    }

    var data = await response.json();
    return { ok: true, keywordList: Array.isArray(data && data.keywordList) ? data.keywordList : [] };
  } catch (err) {
    if (err && err.name === 'AbortError') {
      return { ok: false, keywordList: [], error: { code: 'timeout', message: '검색광고 API 응답이 ' + Math.round(limit / 1000) + '초 안에 오지 않았습니다. 다시 시도해 주세요.' } };
    }
    return { ok: false, keywordList: [], error: { code: 'network', message: '네트워크 오류로 검색량을 불러오지 못했습니다. 연결을 확인해 주세요.' } };
  } finally {
    clearTimeout(timer);
  }
}

/* 네이버 자동완성 — 실패해도 빈 배열. (1차 keywordstool 결과는 그대로 살린다) */
async function fetchAutocomplete(query) {
  var controller = new AbortController();
  var timer = setTimeout(function () { controller.abort(); }, AUTOCOMPLETE_TIMEOUT_MS);
  try {
    var response = await fetch(LOGIC.buildAutocompleteUrl(query), {
      method: 'GET',
      credentials: 'omit',
      cache: 'no-store',
      signal: controller.signal
    });
    if (!response.ok) return [];
    var data = await response.json();
    return LOGIC.parseAutocomplete(data);
  } catch (err) {
    return [];
  } finally {
    clearTimeout(timer);
  }
}

/* 1차 결과 + 자동완성 보충 → 최대 8행. */
async function collectRows(query, keys) {
  var first = await callKeywordTool(LOGIC.buildRequestUrl(query), keys, REQUEST_TIMEOUT_MS);
  if (!first.ok) return first;

  var keywordLists = [first.keywordList];
  var rows = LOGIC.buildRows(LOGIC.mergeKeywordLists(first.keywordList), query, LIMIT);
  var sources = { keywordstool: 1, autocomplete: 0, extraRequests: 0, extraAdded: 0 };

  /* 결과가 8개보다 적을 때만 자동완성으로 보충한다. */
  if (LOGIC.needsExtraRows(rows, LIMIT)) {
    var candidates = await fetchAutocomplete(query);
    sources.autocomplete = candidates.length;

    var extras = LOGIC.selectExtraCandidates(first.keywordList, candidates, LOGIC.MAX_EXTRA_CANDIDATES);
    var batches = LOGIC.buildBatches(extras, LOGIC.EXTRA_BATCH_SIZE).slice(0, LOGIC.MAX_EXTRA_REQUESTS);

    for (var i = 0; i < batches.length; i += 1) {
      var extra = await callKeywordTool(LOGIC.buildMultiRequestUrl(batches[i]), keys, EXTRA_TIMEOUT_MS);
      sources.extraRequests += 1;
      if (!extra.ok) continue; /* 한 묶음이 실패해도 나머지 결과로 계산한다. */
      keywordLists.push(extra.keywordList);
      sources.extraAdded += extra.keywordList.length;

      rows = LOGIC.buildRows(LOGIC.mergeKeywordLists.apply(null, keywordLists), query, LIMIT);
      if (!LOGIC.needsExtraRows(rows, LIMIT)) break;
    }

    rows = LOGIC.buildRows(LOGIC.mergeKeywordLists.apply(null, keywordLists), query, LIMIT);
  }

  return { ok: true, keywordList: LOGIC.mergeKeywordLists.apply(null, keywordLists), rows: rows, sources: sources };
}

async function fetchKeywords(query) {
  var keys = await getKeys();
  if (!LOGIC.isCompleteKeys(keys)) {
    return {
      ok: false,
      error: {
        code: 'no-keys',
        message: '크롬 우측 상단 퍼즐/확장 아이콘에서 네이버 검색광고 API 키를 입력하면 실제 검색량이 표시됩니다.'
      }
    };
  }

  var cached = cache.get(query);
  if (cached && Date.now() - cached.fetchedAt < CACHE_TTL_MS) {
    return { ok: true, rows: cached.rows, query: query, fetchedAt: cached.fetchedAt, cached: true, sources: cached.sources || null };
  }

  var result;
  try {
    result = await collectRows(query, keys);
  } catch (err) {
    return { ok: false, error: { code: 'unknown', message: '알 수 없는 오류: ' + (err && err.message ? err.message : err) } };
  }

  if (!result.ok) {
    return { ok: false, error: result.error, status: result.status };
  }

  var fetchedAt = Date.now();
  cache.set(query, { rows: result.rows, sources: result.sources, fetchedAt: fetchedAt });
  return { ok: true, rows: result.rows, query: query, fetchedAt: fetchedAt, sources: result.sources };
}

chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  if (!msg || typeof msg.type !== 'string') return undefined;

  if (msg.type === 'nkb:key-status') {
    getKeys().then(function (keys) {
      sendResponse({ ok: true, hasKeys: LOGIC.isCompleteKeys(keys) });
    });
    return true;
  }

  if (msg.type === 'nkb:fetch') {
    var query = typeof msg.query === 'string' ? msg.query.trim() : '';
    if (!query) {
      sendResponse({ ok: false, error: { code: 'no-query', message: '검색어가 없습니다.' } });
      return undefined;
    }
    fetchKeywords(query).then(sendResponse).catch(function (err) {
      sendResponse({ ok: false, error: { code: 'unknown', message: '알 수 없는 오류: ' + (err && err.message ? err.message : err) } });
    });
    return true;
  }

  if (msg.type === 'nkb:clear-cache') {
    cache.clear();
    sendResponse({ ok: true });
    return undefined;
  }

  return undefined;
});

/* 키를 새로 저장하면 캐시를 비워 즉시 새 키로 조회한다. */
chrome.storage.onChanged.addListener(function (changes, area) {
  if (area === 'local' && changes[STORAGE_KEY]) cache.clear();
});
