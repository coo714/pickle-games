/* 네이버 연관 키워드 검색량 — 팝업 (API 키 저장 · 버전 표시 · 업데이트 확인)
 * 저장 위치: chrome.storage.local (이 브라우저에만 남는다)
 *
 * 업데이트 확인 원칙
 *  - 원격 JS를 실행하지 않는다. version.json(JSON)만 fetch로 읽는다.
 *  - 자동 설치는 하지 않는다. 새 버전이 있으면 zip 링크를 열어 주기만 한다.
 *  - 확인에 실패해도(오프라인·차단) 아무 것도 막지 않고 조용히 넘어간다.
 */
(function () {
  'use strict';

  var STORAGE_KEY = 'nkbKeys';
  var LOGIC = window.NaverKeywordLogic;

  var UPDATE_JSON_URL = 'https://tools-kr.github.io/updates/naver_keyword_bar/version.json';
  var UPDATE_ZIP_URL = 'https://tools-kr.github.io/updates/naver_keyword_bar/네이버_연관검색어_검색량.zip';
  var UPDATE_ALLOWED_PREFIX = 'https://tools-kr.github.io/updates/naver_keyword_bar/';
  var UPDATE_TIMEOUT_MS = 5000;

  var form = document.getElementById('key-form');
  var statusEl = document.getElementById('status');
  var fields = {
    customerId: document.getElementById('customerId'),
    apiKey: document.getElementById('apiKey'),
    secretKey: document.getElementById('secretKey')
  };

  var versionEl = document.getElementById('appVersion');
  var checkBtn = document.getElementById('checkUpdate');
  var updStatusEl = document.getElementById('updateStatus');
  var noticeEl = document.getElementById('updateNotice');
  var noticeTitle = document.getElementById('updTitle');
  var noticeNote = document.getElementById('updNote');
  var downloadBtn = document.getElementById('updDownload');

  var statusTimer = null;

  function setStatus(message, tone) {
    statusEl.textContent = message;
    statusEl.className = 'pop-status' + (tone ? ' is-' + tone : '');
  }

  /* ---------------- 버전 · 업데이트 ---------------- */

  function currentVersion() {
    try {
      if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getManifest) {
        var v = chrome.runtime.getManifest().version;
        if (v) return String(v);
      }
    } catch (e) { /* 확장 런타임 밖(미리보기)에서는 아래 기본값 */ }
    return (versionEl && versionEl.getAttribute('data-version')) || '2.1.0';
  }

  function setUpdateStatus(message, tone) {
    updStatusEl.textContent = message || '';
    updStatusEl.style.color = tone === 'ok' ? '#0a8f4b' : (tone === 'error' ? '#c8342a' : '');
  }

  /* 같은 경로의 https zip 주소만 연다(JSON이 다른 곳을 가리켜도 무시). */
  function safeZipUrl(candidate) {
    if (typeof candidate === 'string' && candidate.indexOf(UPDATE_ALLOWED_PREFIX) === 0) return candidate;
    return UPDATE_ZIP_URL;
  }

  function openUrl(url) {
    try {
      if (typeof chrome !== 'undefined' && chrome.tabs && chrome.tabs.create) {
        chrome.tabs.create({ url: url });
        return true;
      }
    } catch (e) { /* 아래 window.open으로 */ }
    try {
      window.open(url, '_blank', 'noopener');
      return true;
    } catch (e) {
      return false;
    }
  }

  function showNotice(version, notes, zipUrl) {
    if (!noticeEl) return;
    if (noticeTitle) noticeTitle.textContent = '새 버전 v' + version + ' 출시!';
    if (noticeNote) noticeNote.textContent = notes ? String(notes) : '';
    if (downloadBtn) downloadBtn.setAttribute('data-zip', safeZipUrl(zipUrl));
    noticeEl.hidden = false;
  }

  function hideNotice() {
    if (noticeEl) noticeEl.hidden = true;
  }

  /* version.json 읽기 — 실패하면 null (조용히 무시) */
  function fetchRemoteVersion() {
    if (typeof fetch !== 'function') return Promise.resolve(null);
    var controller = typeof AbortController === 'function' ? new AbortController() : null;
    var timer = controller ? setTimeout(function () { controller.abort(); }, UPDATE_TIMEOUT_MS) : null;

    return fetch(UPDATE_JSON_URL + '?t=' + Date.now(), {
      method: 'GET',
      cache: 'no-store',
      credentials: 'omit',
      signal: controller ? controller.signal : undefined
    }).then(function (response) {
      if (!response || !response.ok) return null;
      return response.json();
    }).then(function (data) {
      if (!data || typeof data.version !== 'string' || !data.version.trim()) return null;
      return {
        version: data.version.trim().replace(/^v/i, ''),
        notes: typeof data.notes === 'string' ? data.notes.split('\n')[0].slice(0, 120) : '',
        downloadUrl: data.download_url
      };
    }).catch(function () {
      return null;
    }).then(function (result) {
      if (timer) clearTimeout(timer);
      return result;
    });
  }

  /* manual=true → 버튼으로 직접 확인: 결과를 항상 한 줄로 알려준다. */
  function checkUpdates(manual) {
    var current = currentVersion();
    if (manual && checkBtn) {
      checkBtn.disabled = true;
      setUpdateStatus('확인 중…', '');
    }

    return fetchRemoteVersion().then(function (remote) {
      if (!remote) {
        if (manual) setUpdateStatus('업데이트를 확인하지 못했어요. 연결을 확인해 주세요.', 'error');
        return null;
      }
      if (!LOGIC || !LOGIC.isNewerVersion) {
        if (manual) setUpdateStatus('버전을 비교할 수 없어요.', 'error');
        return remote;
      }
      if (LOGIC.isNewerVersion(remote.version, current)) {
        showNotice(remote.version, remote.notes, remote.downloadUrl);
        if (manual) setUpdateStatus('새 버전 v' + remote.version + '이 있어요.', 'ok');
      } else {
        hideNotice();
        if (manual) setUpdateStatus('최신 버전(v' + current + ')을 쓰고 있어요.', 'ok');
      }
      return remote;
    }).then(function (remote) {
      if (checkBtn) {
        checkBtn.disabled = false;
      }
      return remote;
    });
  }

  function bootUpdateUi() {
    var version = currentVersion();
    if (versionEl) {
      versionEl.textContent = 'v' + version;
      versionEl.setAttribute('data-version', version);
    }
    if (checkBtn) checkBtn.addEventListener('click', function () { checkUpdates(true); });
    if (downloadBtn) {
      downloadBtn.addEventListener('click', function () {
        var url = safeZipUrl(downloadBtn.getAttribute('data-zip'));
        if (!openUrl(url)) setUpdateStatus('브라우저에서 링크를 열지 못했어요: ' + url, 'error');
      });
    }
    /* 팝업을 열면 백그라운드로 조용히 한 번 확인한다. */
    setTimeout(function () { checkUpdates(false); }, 350);
  }

  /* ---------------- API 키 저장 ---------------- */

  function loadKeys() {
    chrome.storage.local.get(STORAGE_KEY, function (result) {
      var keys = result && result[STORAGE_KEY];
      if (!keys) {
        setStatus('');
        return;
      }
      fields.customerId.value = keys.customerId || '';
      fields.apiKey.value = keys.apiKey || '';
      fields.secretKey.value = keys.secretKey || '';
      if (LOGIC && LOGIC.isCompleteKeys(keys)) setStatus('저장된 키로 조회 중입니다.', 'ok');
    });
  }

  function saveKeys(event) {
    event.preventDefault();
    var keys = {
      customerId: fields.customerId.value.replace(/\s+/g, ''),
      apiKey: fields.apiKey.value.trim(),
      secretKey: fields.secretKey.value.trim()
    };

    if (!LOGIC.isCompleteKeys(keys)) {
      setStatus('세 칸을 모두 채워 주세요.', 'error');
      var empty = !keys.customerId ? fields.customerId : (!keys.apiKey ? fields.apiKey : fields.secretKey);
      if (empty && empty.focus) empty.focus();
      return;
    }

    var payload = {};
    payload[STORAGE_KEY] = keys;

    chrome.storage.local.set(payload, function () {
      if (chrome.runtime.lastError) {
        setStatus('저장하지 못했습니다: ' + chrome.runtime.lastError.message, 'error');
        return;
      }
      setStatus('저장됨 ✓ 네이버 검색 결과에 바로 반영됩니다.', 'ok');
      if (statusTimer) clearTimeout(statusTimer);
      statusTimer = setTimeout(function () { setStatus('저장된 키로 조회 중입니다.', 'ok'); }, 2600);
    });
  }

  form.addEventListener('submit', saveKeys);
  loadKeys();
  bootUpdateUi();
})();
