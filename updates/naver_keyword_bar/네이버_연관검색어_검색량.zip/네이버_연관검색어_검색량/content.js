/* 네이버 연관 키워드 검색량 — content script
 * search.naver.com 통합검색 결과 상단(#main_pack 최상단)에 카드를 넣는다.
 * 검색량 조회는 background 서비스 워커에 맡긴다(CORS 회피 + 키 보관).
 */
(function () {
  'use strict';

  if (window.top !== window) return;

  var LOGIC = window.NaverKeywordLogic;
  if (!LOGIC) return;

  var CARD_ID = 'nkb-card';
  var COLLAPSE_KEY = 'nkbCollapsed';
  var LIMIT = LOGIC.DEFAULT_LIMIT;
  var COPY_FLASH_MS = 1600;

  var state = {
    query: '',
    phase: 'idle', /* idle | loading | need-keys | ready | error | demo */
    rows: [],
    error: null,
    demo: false,
    collapsed: false,
    requestSeq: 0
  };

  var card = null;
  var els = {};
  var lastHref = location.href;
  var copyTimer = null;

  var CHEVRON_UP = '<svg class="nkb-chev" width="12" height="12" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M6 15l6-6 6 6" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  var CHEVRON_DOWN = '<svg class="nkb-chev" width="12" height="12" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M6 9l6 6 6-6" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>';

  /* ---------- 검색어 ---------- */

  function currentQuery() {
    try {
      var params = new URLSearchParams(location.search);
      var fromUrl = params.get('query');
      if (fromUrl) return fromUrl.replace(/\s+/g, ' ').trim();
    } catch (e) { /* ignore */ }
    var input = document.querySelector('#nx_query, input[name="query"], input[type="search"]');
    if (input && typeof input.value === 'string' && input.value.trim()) return input.value.trim();
    var heading = document.querySelector('#search_input');
    return heading && heading.value ? String(heading.value).trim() : '';
  }

  /* ---------- 카드 골격 ---------- */

  function findAnchor() {
    return document.querySelector('#main_pack')
      || document.querySelector('#content')
      || document.querySelector('#container')
      || document.querySelector('main');
  }

  function el(tag, className, text) {
    var node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined && text !== null) node.textContent = text;
    return node;
  }

  function buildCard() {
    var section = document.createElement('section');
    section.id = CARD_ID;
    section.className = 'nkb-card';
    section.setAttribute('data-nkb', 'card');

    var head = el('div', 'nkb-head');
    var brand = el('div', 'nkb-brand');
    brand.appendChild(el('span', 'nkb-badge', 'N'));
    brand.appendChild(el('h2', 'nkb-title', '연관 키워드 검색량'));
    var sub = el('span', 'nkb-sub', '');
    brand.appendChild(sub);

    var actions = el('div', 'nkb-actions');
    var toggle = el('button', 'nkb-toggle');
    toggle.type = 'button';
    toggle.setAttribute('aria-expanded', 'true');
    var toggleLabel = el('span', 'nkb-toggle-label', '접기');
    toggle.appendChild(toggleLabel);
    toggle.insertAdjacentHTML('beforeend', CHEVRON_UP);

    var copy = el('button', 'nkb-copy', '전체 복사');
    copy.type = 'button';

    actions.appendChild(toggle);
    actions.appendChild(copy);
    head.appendChild(brand);
    head.appendChild(actions);

    var body = el('div', 'nkb-body');

    section.appendChild(head);
    section.appendChild(body);

    els.section = section;
    els.sub = sub;
    els.toggle = toggle;
    els.toggleLabel = toggleLabel;
    els.copy = copy;
    els.body = body;

    toggle.addEventListener('click', function () {
      state.collapsed = !state.collapsed;
      saveCollapsed(state.collapsed);
      render();
    });

    copy.addEventListener('click', onCopy);

    return section;
  }

  function ensureCard() {
    if (card && card.isConnected) return card;
    var anchor = findAnchor();
    if (!anchor) return null;
    if (!card) card = buildCard();
    anchor.insertBefore(card, anchor.firstElementChild || null);
    render();
    return card;
  }

  function saveCollapsed(value) {
    try {
      var payload = {};
      payload[COLLAPSE_KEY] = !!value;
      chrome.storage.local.set(payload);
    } catch (e) { /* ignore */ }
  }

  /* ---------- 렌더 ---------- */

  function render() {
    if (!els.section) return;

    var query = state.query;
    var subText = "'" + query + "' 기준 상위 " + LIMIT + "개";
    if (state.demo) subText += ' · 데모 데이터';
    els.sub.textContent = subText;

    els.toggleLabel.textContent = state.collapsed ? '펼치기' : '접기';
    els.toggle.setAttribute('aria-expanded', state.collapsed ? 'false' : 'true');
    els.toggle.querySelector('.nkb-chev').outerHTML = state.collapsed ? CHEVRON_DOWN : CHEVRON_UP;

    els.body.hidden = !!state.collapsed;
    els.body.textContent = '';

    els.copy.disabled = !(state.phase === 'ready' && state.rows.length > 0);

    if (state.collapsed) return;

    if (state.phase === 'loading') els.body.appendChild(buildSkeleton());
    else if (state.phase === 'need-keys') els.body.appendChild(buildNotice());
    else if (state.phase === 'error') els.body.appendChild(buildError());
    else if (state.phase === 'demo' || state.phase === 'ready') {
      els.body.appendChild(buildTable());
      if (state.phase === 'demo') els.body.appendChild(buildDemoNote());
      els.body.appendChild(buildFoot());
    }
  }

  function buildSkeleton() {
    var wrap = el('div', 'nkb-skeleton');
    wrap.setAttribute('aria-hidden', 'true');
    for (var i = 0; i < 5; i += 1) {
      var row = el('div', 'nkb-skel-row');
      row.appendChild(el('span', 'nkb-skel nkb-skel-rank'));
      row.appendChild(el('span', 'nkb-skel nkb-skel-kw'));
      row.appendChild(el('span', 'nkb-skel nkb-skel-bar'));
      row.appendChild(el('span', 'nkb-skel nkb-skel-total'));
      wrap.appendChild(row);
    }
    var live = el('span', 'nkb-sr', '검색량을 불러오는 중입니다.');
    wrap.appendChild(live);
    return wrap;
  }

  function buildNotice() {
    var wrap = el('div', 'nkb-notice');
    var text = el('p', 'nkb-notice-text');
    text.textContent = '크롬 우측 상단 퍼즐/확장 아이콘에서 네이버 검색광고 API 키를 입력하면 실제 검색량이 표시됩니다.';
    wrap.appendChild(text);

    var row = el('div', 'nkb-notice-actions');
    var demoBtn = el('button', 'nkb-ghost', '데모 미리보기');
    demoBtn.type = 'button';
    demoBtn.addEventListener('click', function () {
      state.demo = true;
      state.phase = 'demo';
      state.rows = LOGIC.demoRows(state.query, LIMIT);
      render();
    });
    row.appendChild(demoBtn);
    wrap.appendChild(row);
    return wrap;
  }

  function buildDemoNote() {
    var note = el('div', 'nkb-demo-note');
    note.appendChild(el('span', 'nkb-chip', '데모'));
    note.appendChild(el('span', 'nkb-demo-text', '실제 검색량이 아닙니다. API 키를 저장하면 이 검색어의 진짜 수치가 표시됩니다.'));
    var close = el('button', 'nkb-link-btn', '데모 닫기');
    close.type = 'button';
    close.addEventListener('click', function () {
      state.demo = false;
      state.rows = [];
      state.phase = 'need-keys';
      render();
    });
    note.appendChild(close);
    return note;
  }

  function buildError() {
    var wrap = el('div', 'nkb-error');
    var info = state.error || {};
    var box = el('div', 'nkb-error-box');
    box.appendChild(el('span', 'nkb-error-mark', '!'));
    var textWrap = el('div', 'nkb-error-text');
    textWrap.appendChild(el('p', 'nkb-error-msg', info.message || '검색량을 불러오지 못했습니다.'));
    if (info.code === 'auth' || info.code === 'no-keys') {
      textWrap.appendChild(el('p', 'nkb-error-hint', 'API 키는 크롬 우측 상단 확장 아이콘을 눌러 다시 저장할 수 있습니다.'));
    }
    box.appendChild(textWrap);
    wrap.appendChild(box);

    var retry = el('button', 'nkb-ghost', '다시 시도');
    retry.type = 'button';
    retry.addEventListener('click', function () { load(state.query); });
    wrap.appendChild(retry);
    return wrap;
  }

  function buildTable() {
    var table = el('div', 'nkb-table');

    var headRow = el('div', 'nkb-grid nkb-grid-head');
    headRow.appendChild(el('span', 'nkb-c-rank', '순위'));
    headRow.appendChild(el('span', 'nkb-c-kw', '키워드 (클릭 시 재검색)'));
    headRow.appendChild(el('span', 'nkb-c-bar', '검색량 비율'));
    headRow.appendChild(el('span', 'nkb-c-total', '총 검색량'));
    table.appendChild(headRow);

    if (!state.rows.length) {
      table.appendChild(el('p', 'nkb-empty', '연관 키워드를 찾지 못했습니다. 다른 검색어로 시도해 보세요.'));
      return table;
    }

    var rows = el('div', 'nkb-rows');
    state.rows.forEach(function (row) { rows.appendChild(buildRow(row)); });
    table.appendChild(rows);
    return table;
  }

  function buildRow(row) {
    var item = el('div', 'nkb-row' + (row.rank === 1 ? ' nkb-top' : ''));
    item.setAttribute('role', 'link');
    item.setAttribute('tabindex', '0');
    item.setAttribute('aria-label', row.keyword + ' 다시 검색');
    item.title = row.keyword + ' 다시 검색';

    item.appendChild(el('span', 'nkb-rank', String(row.rank)));
    item.appendChild(el('span', 'nkb-kw', row.keyword));

    var barCell = el('span', 'nkb-bar-cell');
    var bar = el('span', 'nkb-bar');
    bar.style.width = Math.max(row.percent, 2) + '%';
    barCell.appendChild(bar);
    item.appendChild(barCell);

    item.appendChild(el('span', 'nkb-total', LOGIC.formatNumber(row.total)));

    function go(event) {
      if (event) event.preventDefault();
      location.href = 'https://search.naver.com/search.naver?query=' + encodeURIComponent(row.keyword);
    }

    item.addEventListener('click', go);
    item.addEventListener('keydown', function (event) {
      if (event.key === 'Enter' || event.key === ' ') go(event);
    });

    return item;
  }

  function buildFoot() {
    var foot = el('p', 'nkb-foot');
    foot.textContent = '※ API 키 설정은 크롬 우측 상단 확장 아이콘에서 변경 가능 · 키워드 클릭 시 네이버 재검색';
    return foot;
  }

  /* ---------- 복사 ---------- */

  function legacyCopy(text) {
    return new Promise(function (resolve, reject) {
      var area = document.createElement('textarea');
      area.value = text;
      area.setAttribute('readonly', '');
      area.className = 'nkb-copy-src';
      document.body.appendChild(area);
      area.select();
      var ok = false;
      try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
      document.body.removeChild(area);
      if (ok) resolve();
      else reject(new Error('copy failed'));
    });
  }

  function copyText(text) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      return navigator.clipboard.writeText(text).catch(function () { return legacyCopy(text); });
    }
    return legacyCopy(text);
  }

  function onCopy() {
    if (state.phase !== 'ready' || !state.rows.length) return;
    var payload = LOGIC.buildCopyText(state.rows);
    copyText(payload).then(function () {
      flashCopied('복사됨 ✓');
    }).catch(function () {
      flashCopied('복사 실패');
    });
  }

  function flashCopied(label) {
    els.copy.textContent = label;
    els.copy.classList.add('is-flashing');
    if (copyTimer) clearTimeout(copyTimer);
    copyTimer = setTimeout(function () {
      els.copy.textContent = '전체 복사';
      els.copy.classList.remove('is-flashing');
      copyTimer = null;
    }, COPY_FLASH_MS);
  }

  /* ---------- 확장 프로그램 통신 ---------- */

  function askBackground(payload, timeoutMs) {
    return new Promise(function (resolve, reject) {
      var settled = false;
      var timer = setTimeout(function () {
        if (settled) return;
        settled = true;
        reject(new Error('timeout'));
      }, timeoutMs || 20000);

      function finish(fn, value) {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        fn(value);
      }

      try {
        chrome.runtime.sendMessage(payload, function (response) {
          var runtimeError = chrome.runtime.lastError;
          if (runtimeError) {
            finish(reject, new Error(runtimeError.message || 'runtime error'));
            return;
          }
          finish(resolve, response);
        });
      } catch (err) {
        finish(reject, err);
      }
    });
  }

  /* ---------- 상태 흐름 ---------- */

  function setError(code, message) {
    state.phase = 'error';
    state.error = { code: code, message: message };
    state.rows = [];
    render();
  }

  async function load(query) {
    var seq = state.requestSeq + 1;
    state.requestSeq = seq;
    state.error = null;
    state.demo = false;
    state.phase = 'loading';
    render();

    var status;
    try {
      status = await askBackground({ type: 'nkb:key-status' }, 8000);
    } catch (err) {
      if (seq !== state.requestSeq) return;
      setError('bridge', '확장 프로그램과 연결이 끊겼습니다. 페이지를 새로 고침한 뒤 다시 시도해 주세요.');
      return;
    }
    if (seq !== state.requestSeq) return;

    if (!status || !status.hasKeys) {
      state.phase = 'need-keys';
      state.rows = [];
      render();
      return;
    }

    var result;
    try {
      /* 1차 keywordstool 호출 + 자동완성 보충(최대 2회)까지 기다린다. */
      result = await askBackground({ type: 'nkb:fetch', query: query }, 30000);
    } catch (err) {
      if (seq !== state.requestSeq) return;
      if (err && err.message === 'timeout') setError('timeout', '검색광고 API 응답이 너무 늦습니다. 잠시 후 다시 시도해 주세요.');
      else setError('bridge', '확장 프로그램과 연결이 끊겼습니다. 페이지를 새로 고침한 뒤 다시 시도해 주세요.');
      return;
    }
    if (seq !== state.requestSeq) return;

    if (result && result.ok) {
      state.rows = Array.isArray(result.rows) ? result.rows : [];
      state.phase = 'ready';
      render();
      return;
    }

    var error = (result && result.error) || { code: 'unknown', message: '검색량을 불러오지 못했습니다.' };
    setError(error.code || 'unknown', error.message || '검색량을 불러오지 못했습니다.');
  }

  /* ---------- 부팅과 변경 감시 ---------- */

  function boot() {
    var query = currentQuery();
    if (!query) {
      if (card && card.parentNode) card.parentNode.removeChild(card);
      state.query = '';
      return;
    }
    if (!ensureCard()) return;
    if (query !== state.query) {
      state.query = query;
      state.rows = [];
      state.error = null;
      load(query);
    } else {
      render();
    }
  }

  /* 팝업에서 키를 새로 저장하면 지금 보고 있는 카드도 바로 새 키로 다시 조회한다. */
  function onStorageChanged(changes, area) {
    if (area !== 'local' || !changes || !changes.nkbKeys) return;
    if (!state.query) return;
    load(state.query);
  }

  function startWatching() {
    setInterval(function () {
      var hrefChanged = location.href !== lastHref;
      if (hrefChanged) lastHref = location.href;
      var query = currentQuery();
      var cardMissing = !!state.query && (!card || !card.isConnected);
      if (hrefChanged || query !== state.query || cardMissing) boot();
    }, 800);
  }

  function init() {
    try {
      chrome.storage.local.get(COLLAPSE_KEY, function (result) {
        if (!chrome.runtime.lastError && result && typeof result[COLLAPSE_KEY] === 'boolean') {
          state.collapsed = result[COLLAPSE_KEY];
        }
        boot();
      });
    } catch (e) {
      boot();
    }

    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', boot, { once: true });
    }
    try {
      chrome.storage.onChanged.addListener(onStorageChanged);
    } catch (e) { /* ignore */ }
    startWatching();
  }

  init();
})();
